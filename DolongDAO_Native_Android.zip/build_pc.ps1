$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

$ToolsDir = Join-Path $ProjectRoot ".pc_build_tools"
New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null

# 1. Kiem tra hoac tai Portable JDK 17
$JdkDir = Join-Path $ToolsDir "jdk17"
$JavaExe = Get-ChildItem -Path $JdkDir -Filter "java.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $JavaExe) {
    Write-Host "[1/4] Dang tai Portable OpenJDK 17 (khoang 180MB)..." -ForegroundColor Cyan
    $JdkZip = Join-Path $ToolsDir "jdk17.zip"
    $JdkUrl = "https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk"
    Invoke-WebRequest -Uri $JdkUrl -OutFile $JdkZip -UseBasicParsing
    Expand-Archive -Path $JdkZip -DestinationPath $JdkDir -Force
    Remove-Item $JdkZip -Force
    $JavaExe = Get-ChildItem -Path $JdkDir -Filter "java.exe" -Recurse | Select-Object -First 1
}
$JavaHome = Split-Path -Parent (Split-Path -Parent $JavaExe.FullName)
$env:JAVA_HOME = $JavaHome
$env:PATH = "$JavaHome\bin;$env:PATH"
Write-Host "-> JDK 17 san sang tai: $JavaHome" -ForegroundColor Green

# 2. Kiem tra hoac tai Android Command-Line Tools & SDK 34
$SdkDir = Join-Path $ToolsDir "android-sdk"
$CmdToolsZip = Join-Path $ToolsDir "cmdline-tools.zip"
$SdkManagerBat = Join-Path $SdkDir "cmdline-tools\bin\sdkmanager.bat"
if (-not (Test-Path $SdkManagerBat)) {
    Write-Host "[2/4] Dang tai Android SDK Command-Line Tools..." -ForegroundColor Cyan
    New-Item -ItemType Directory -Force -Path $SdkDir | Out-Null
    $CmdUrl = "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip"
    Invoke-WebRequest -Uri $CmdUrl -OutFile $CmdToolsZip -UseBasicParsing
    Expand-Archive -Path $CmdToolsZip -DestinationPath $SdkDir -Force
    Remove-Item $CmdToolsZip -Force
}

$Platform34Dir = Join-Path $SdkDir "platforms\android-34"
if (-not (Test-Path $Platform34Dir)) {
    Write-Host "[2.5/4] Dang cai dat Android SDK Platform 34 & Build-Tools 34.0.0..." -ForegroundColor Cyan
    $YesInput = "y`r`ny`r`ny`r`ny`r`ny`r`ny`r`ny`r`n"
    $YesInput | & $SdkManagerBat --sdk_root="$SdkDir" --licenses | Out-Null
    & $SdkManagerBat --sdk_root="$SdkDir" "platform-tools" "platforms;android-34" "build-tools;34.0.0"
}
$env:ANDROID_HOME = $SdkDir
$env:ANDROID_SDK_ROOT = $SdkDir

# Ghi file local.properties
$EscapedSdk = $SdkDir.Replace("\", "\\")
Set-Content -Path (Join-Path $ProjectRoot "local.properties") -Value "sdk.dir=$EscapedSdk" -Encoding UTF8
Write-Host "-> Android SDK 34 san sang!" -ForegroundColor Green

# 3. Kiem tra hoac tai Gradle 8.5
$GradleDir = Join-Path $ToolsDir "gradle-8.5"
$GradleBat = Get-ChildItem -Path $GradleDir -Filter "gradle.bat" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $GradleBat) {
    Write-Host "[3/4] Dang tai Gradle 8.5..." -ForegroundColor Cyan
    $GradleZip = Join-Path $ToolsDir "gradle.zip"
    $GradleUrl = "https://services.gradle.org/distributions/gradle-8.5-bin.zip"
    Invoke-WebRequest -Uri $GradleUrl -OutFile $GradleZip -UseBasicParsing
    Expand-Archive -Path $GradleZip -DestinationPath $GradleDir -Force
    Remove-Item $GradleZip -Force
    $GradleBat = Get-ChildItem -Path $GradleDir -Filter "gradle.bat" -Recurse | Select-Object -First 1
}
Write-Host "-> Gradle 8.5 san sang!" -ForegroundColor Green

# 4. Tien hanh bien dich ra file DolongDAO-Native.apk
Write-Host "[4/4] Dang bien dich ma nguon Java sang DolongDAO-Native.apk..." -ForegroundColor Yellow
& $GradleBat.FullName assembleDebug --no-daemon

$BuiltApk = Join-Path $ProjectRoot "app\build\outputs\apk\debug\app-debug.apk"
$DestApk = Join-Path $ProjectRoot "DolongDAO-Native.apk"
if (Test-Path $BuiltApk) {
    Copy-Item -Path $BuiltApk -Destination $DestApk -Force
    Write-Host ""
    Write-Host "============================================================================" -ForegroundColor Green
    Write-Host "  THANH CONG 100%! FILE APK DA DUOC TAO TAI:" -ForegroundColor Green
    Write-Host "  $DestApk" -ForegroundColor White
    Write-Host "  Hay gui file DolongDAO-Native.apk nay qua Zalo sang dien thoai de cai dat!" -ForegroundColor Green
    Write-Host "============================================================================" -ForegroundColor Green
    explorer.exe "/select,$DestApk"
} else {
    Write-Host "Co loi khi bien dich APK. Vui long kiem tra thong bao phia tren." -ForegroundColor Red
}
