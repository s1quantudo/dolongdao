@echo off
chcp 65001 >nul
title TU DONG DONG GOI DOLONGDAO-NATIVE.APK TREN PC
echo ============================================================================
echo   CONG CU TU DONG BIEN DICH DOLONGDAO-NATIVE.APK TREN WINDOWS PC
echo   (Khong can cai dat Android Studio - Tu dong tai JDK 17, SDK 34 va Gradle)
echo ============================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_pc.ps1"
echo.
pause
