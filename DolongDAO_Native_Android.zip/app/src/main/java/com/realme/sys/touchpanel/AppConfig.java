package com.realme.sys.touchpanel;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class AppConfig {
    private static final String PREF_NAME = "dolongdao_native_store_v2";
    private static final String KEY_JSON = "config_json_v2";

    public static final String[] PRIORITY_HANOI_AREAS = new String[]{
        "Ba Đình", "Hoàn Kiếm", "Đống Đa", "Hai Bà Trưng",
        "Cầu Giấy", "Thanh Xuân", "Hoàng Mai", "Long Biên",
        "Tây Hồ", "Hà Đông", "Bắc Từ Liêm", "Nam Từ Liêm",
        "Thanh Trì", "Hoài Đức", "Gia Lâm", "Thường Tín",
        "Đông Anh", "Thanh Oai"
    };

    public static final String[] OUTER_HANOI_AREAS = new String[]{
        "Sóc Sơn", "Mê Linh", "Chương Mỹ", "Đan Phượng",
        "Phúc Thọ", "Quốc Oai", "Thạch Thất", "Ứng Hòa",
        "Mỹ Đức", "Phú Xuyên", "Ba Vì", "Sơn Tây"
    };

    public static final String[] BUNDLE_KEYS = new String[]{"b1", "b2", "b3", "b4", "b5"};
    public static final String[] BUNDLE_LABELS = new String[]{
        "Đơn 1 (Solo)", "Chùm 2 đơn", "Chùm 3 đơn", "Chùm 4 đơn", "Chùm 5 đơn trở lên"
    };
    public static final int[] BUNDLE_COUNTS = new int[]{1, 2, 3, 4, 5};
    public static final String[] BUNDLE_MODES = new String[]{"exact", "exact", "exact", "exact", "ge"};

    public static class DynamicRule {
        public String id;
        public String op; // "ge" or "le"
        public double val;
        public boolean pri;
        public boolean norm;

        public DynamicRule(String id, String op, double val, boolean pri, boolean norm) {
            this.id = id;
            this.op = op;
            this.val = val;
            this.pri = pri;
            this.norm = norm;
        }

        public String formatLabel(String unit) {
            String numStr = (val == Math.floor(val)) ? String.valueOf((long) val) : String.valueOf(val);
            if ("ge".equals(op)) {
                return "Từ " + numStr + unit + " trở lên";
            }
            return "Từ " + numStr + unit + " trở xuống";
        }
    }

    public static class TierState {
        public boolean pri;
        public boolean norm;

        public TierState(boolean pri, boolean norm) {
            this.pri = pri;
            this.norm = norm;
        }
    }

    public static class BadShopItem {
        public String name;
        public String addr;

        public BadShopItem(String name, String addr) {
            this.name = name != null ? name.trim() : "";
            this.addr = addr != null ? addr.trim() : "";
        }
    }

    public String runMode = "SHOPEE"; // "SHOPEE" or "FOOD"
    public int priorityMinutes = 10;
    public int maxEscrowMinK = 1500;
    public int loadMapDelayMs = 2000;
    public int swipeDurationMs = 150;
    public int afterSwipeDelayMs = 300;

    public List<DynamicRule> shopeeKmRules = new ArrayList<>();
    public List<DynamicRule> shopeeBasePayRules = new ArrayList<>();
    public List<DynamicRule> shopeeExtraPayRules = new ArrayList<>();
    public List<DynamicRule> foodKmRules = new ArrayList<>();

    public Map<String, TierState> bundleRules = new HashMap<>();
    public Map<String, TierState> prefAreas = new HashMap<>();
    public Map<String, Boolean> avoidAreas = new HashMap<>();
    public List<BadShopItem> badShops = new ArrayList<>();

    // Tọa độ mặc định cho Realme Neo 7 (1080x2376)
    public int reloadX = 79;
    public int reloadY = 874;
    public int expandX = 1006;
    public int expandY = 2032;
    public int backX = 58;
    public int backY = 178;

    // Tọa độ 2 (Đầu vuốt) -> Tọa độ 1 (Cuối vuốt)
    public int swipeStartX = 920;
    public int swipeStartY = 1950;
    public int swipeEndX = 160;
    public int swipeEndY = 1950;

    public String savedWhitelistedFp = "";
    public long savedWhitelistedTime = 0L;

    public static AppConfig createDefaults() {
        AppConfig c = new AppConfig();
        c.shopeeKmRules.add(new DynamicRule("km_1", "le", 2, false, false));
        c.shopeeKmRules.add(new DynamicRule("km_2", "ge", 15, false, false));
        c.shopeeKmRules.add(new DynamicRule("km_3", "ge", 20, false, false));
        c.shopeeKmRules.add(new DynamicRule("km_4", "ge", 25, false, false));

        c.shopeeBasePayRules.add(new DynamicRule("bp_1", "le", 14, false, false));
        c.shopeeBasePayRules.add(new DynamicRule("bp_2", "ge", 60, false, false));
        c.shopeeBasePayRules.add(new DynamicRule("bp_3", "ge", 80, false, false));
        c.shopeeBasePayRules.add(new DynamicRule("bp_4", "ge", 100, false, false));

        c.shopeeExtraPayRules.add(new DynamicRule("ep_1", "ge", 10, false, false));
        c.shopeeExtraPayRules.add(new DynamicRule("ep_2", "ge", 20, false, false));

        c.foodKmRules.add(new DynamicRule("fkm_1", "le", 3, false, false));
        c.foodKmRules.add(new DynamicRule("fkm_2", "ge", 10, false, false));

        for (String k : BUNDLE_KEYS) {
            c.bundleRules.put(k, new TierState(false, false));
        }
        return c;
    }

    public static synchronized AppConfig load(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_JSON, null);
        if (raw == null || raw.isEmpty()) {
            AppConfig def = createDefaults();
            def.save(ctx);
            return def;
        }
        try {
            JSONObject o = new JSONObject(raw);
            AppConfig c = new AppConfig();
            c.runMode = o.optString("runMode", "SHOPEE");
            c.priorityMinutes = o.optInt("priorityMinutes", 10);
            c.maxEscrowMinK = o.optInt("maxEscrowMinK", 1500);
            c.loadMapDelayMs = Math.max(300, o.optInt("loadMapDelayMs", 2000));
            c.swipeDurationMs = Math.max(40, o.optInt("swipeDurationMs", 150));
            c.afterSwipeDelayMs = Math.max(40, o.optInt("afterSwipeDelayMs", 300));

            c.shopeeKmRules = parseRulesArray(o.optJSONArray("shopeeKmRules"));
            c.shopeeBasePayRules = parseRulesArray(o.optJSONArray("shopeeBasePayRules"));
            c.shopeeExtraPayRules = parseRulesArray(o.optJSONArray("shopeeExtraPayRules"));
            c.foodKmRules = parseRulesArray(o.optJSONArray("foodKmRules"));

            for (String k : BUNDLE_KEYS) {
                c.bundleRules.put(k, new TierState(false, false));
            }
            JSONObject bObj = o.optJSONObject("bundleRules");
            if (bObj != null) {
                for (String k : BUNDLE_KEYS) {
                    JSONObject item = bObj.optJSONObject(k);
                    if (item != null) {
                        c.bundleRules.put(k, new TierState(item.optBoolean("pri", false), item.optBoolean("norm", false)));
                    }
                }
            }

            JSONObject prefObj = o.optJSONObject("prefAreas");
            if (prefObj != null) {
                Iterator<String> keys = prefObj.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    JSONObject item = prefObj.optJSONObject(k);
                    if (item != null) {
                        c.prefAreas.put(k, new TierState(item.optBoolean("pri", false), item.optBoolean("norm", false)));
                    }
                }
            }

            JSONObject avoidObj = o.optJSONObject("avoidAreas");
            if (avoidObj != null) {
                Iterator<String> keys = avoidObj.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    if (avoidObj.optBoolean(k, false)) {
                        c.avoidAreas.put(k, true);
                    }
                }
            }

            JSONArray bsArr = o.optJSONArray("badShops");
            if (bsArr != null) {
                for (int i = 0; i < bsArr.length(); i++) {
                    JSONObject b = bsArr.optJSONObject(i);
                    if (b != null) {
                        c.badShops.add(new BadShopItem(b.optString("name", ""), b.optString("addr", "")));
                    }
                }
            }

            c.reloadX = o.optInt("reloadX", 79);
            c.reloadY = o.optInt("reloadY", 874);
            c.expandX = o.optInt("expandX", 1006);
            c.expandY = o.optInt("expandY", 2032);
            c.backX = o.optInt("backX", 58);
            c.backY = o.optInt("backY", 178);

            c.swipeStartX = o.optInt("swipeStartX", 920);
            c.swipeStartY = o.optInt("swipeStartY", 1950);
            c.swipeEndX = o.optInt("swipeEndX", 160);
            c.swipeEndY = o.optInt("swipeEndY", 1950);

            c.savedWhitelistedFp = o.optString("savedWhitelistedFp", "");
            c.savedWhitelistedTime = o.optLong("savedWhitelistedTime", 0L);
            return c;
        } catch (Exception e) {
            return createDefaults();
        }
    }

    public synchronized void save(Context ctx) {
        try {
            JSONObject o = new JSONObject();
            o.put("runMode", runMode);
            o.put("priorityMinutes", priorityMinutes);
            o.put("maxEscrowMinK", maxEscrowMinK);
            o.put("loadMapDelayMs", Math.max(300, loadMapDelayMs));
            o.put("swipeDurationMs", Math.max(40, swipeDurationMs));
            o.put("afterSwipeDelayMs", Math.max(40, afterSwipeDelayMs));

            o.put("shopeeKmRules", serializeRulesArray(shopeeKmRules));
            o.put("shopeeBasePayRules", serializeRulesArray(shopeeBasePayRules));
            o.put("shopeeExtraPayRules", serializeRulesArray(shopeeExtraPayRules));
            o.put("foodKmRules", serializeRulesArray(foodKmRules));

            JSONObject bObj = new JSONObject();
            for (Map.Entry<String, TierState> en : bundleRules.entrySet()) {
                JSONObject st = new JSONObject();
                st.put("pri", en.getValue().pri);
                st.put("norm", en.getValue().norm);
                bObj.put(en.getKey(), st);
            }
            o.put("bundleRules", bObj);

            JSONObject prefObj = new JSONObject();
            for (Map.Entry<String, TierState> en : prefAreas.entrySet()) {
                JSONObject st = new JSONObject();
                st.put("pri", en.getValue().pri);
                st.put("norm", en.getValue().norm);
                prefObj.put(en.getKey(), st);
            }
            o.put("prefAreas", prefObj);

            JSONObject avoidObj = new JSONObject();
            for (Map.Entry<String, Boolean> en : avoidAreas.entrySet()) {
                if (Boolean.TRUE.equals(en.getValue())) {
                    avoidObj.put(en.getKey(), true);
                }
            }
            o.put("avoidAreas", avoidObj);

            JSONArray bsArr = new JSONArray();
            for (BadShopItem item : badShops) {
                JSONObject b = new JSONObject();
                b.put("name", item.name);
                b.put("addr", item.addr);
                bsArr.put(b);
            }
            o.put("badShops", bsArr);

            o.put("reloadX", reloadX);
            o.put("reloadY", reloadY);
            o.put("expandX", expandX);
            o.put("expandY", expandY);
            o.put("backX", backX);
            o.put("backY", backY);

            o.put("swipeStartX", swipeStartX);
            o.put("swipeStartY", swipeStartY);
            o.put("swipeEndX", swipeEndX);
            o.put("swipeEndY", swipeEndY);

            o.put("savedWhitelistedFp", savedWhitelistedFp != null ? savedWhitelistedFp : "");
            o.put("savedWhitelistedTime", savedWhitelistedTime);

            SharedPreferences sp = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            sp.edit().putString(KEY_JSON, o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private static List<DynamicRule> parseRulesArray(JSONArray arr) {
        List<DynamicRule> list = new ArrayList<>();
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            if (r != null) {
                list.add(new DynamicRule(
                    r.optString("id", "r_" + i),
                    r.optString("op", "ge"),
                    r.optDouble("val", 0.0),
                    r.optBoolean("pri", false),
                    r.optBoolean("norm", false)
                ));
            }
        }
        return list;
    }

    private static JSONArray serializeRulesArray(List<DynamicRule> list) {
        JSONArray arr = new JSONArray();
        if (list == null) return arr;
        for (DynamicRule r : list) {
            try {
                JSONObject o = new JSONObject();
                o.put("id", r.id);
                o.put("op", r.op);
                o.put("val", r.val);
                o.put("pri", r.pri);
                o.put("norm", r.norm);
                arr.put(o);
            } catch (Exception ignored) {
            }
        }
        return arr;
    }

    public boolean addShopToBlacklist(Context ctx, String shopName, String shopAddr) {
        String cleanName = shopName != null ? shopName.trim() : "";
        String cleanAddr = shopAddr != null ? shopAddr.trim() : "";
        if (cleanName.isEmpty() && cleanAddr.isEmpty()) return false;
        for (BadShopItem existing : badShops) {
            if (existing.name.equals(cleanName) && existing.addr.equals(cleanAddr)) {
                return false;
            }
        }
        badShops.add(new BadShopItem(cleanName, cleanAddr));
        save(ctx);
        return true;
    }
}
