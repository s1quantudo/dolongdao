package com.realme.sys.touchpanel;

import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RunLogger {
    private static final int MAX_LINES = 800;
    private static final List<String> logs = new ArrayList<>();
    private static final SimpleDateFormat TIME_FMT = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    public static synchronized void log(String msg) {
        String line = "[" + TIME_FMT.format(new Date()) + "] " + msg;
        logs.add(line);
        while (logs.size() > MAX_LINES) {
            logs.remove(0);
        }
        appendToDownloadFile(line + "\n");
    }

    public static synchronized void logDivider(int cycleNum) {
        String div = "\n--------------------- [ ĐỢT LOAD MAP #" + cycleNum + " ] ---------------------\n";
        logs.add(div);
        while (logs.size() > MAX_LINES) {
            logs.remove(0);
        }
        appendToDownloadFile(div + "\n");
    }

    public static synchronized void clear() {
        logs.clear();
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (dir != null) {
                File f = new File(dir, "dolongdao_run_log.txt");
                if (f.exists()) {
                    f.delete();
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static synchronized String getAllLogsText() {
        if (logs.isEmpty()) {
            return "Chưa có nhật ký nào. Hãy bật Thanh Nổi và bấm [CHẠY] hoặc [📌] để ghi nhật ký hoạt động.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < logs.size(); i++) {
            sb.append(logs.get(i)).append("\n");
        }
        return sb.toString();
    }

    private static void appendToDownloadFile(String text) {
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (dir != null) {
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, "dolongdao_run_log.txt");
                FileOutputStream fos = new FileOutputStream(f, true);
                fos.write(text.getBytes(StandardCharsets.UTF_8));
                fos.close();
            }
        } catch (Exception ignored) {
        }
    }
}
