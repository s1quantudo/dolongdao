package com.realme.sys.touchpanel;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreenParser {

    public static class NodeItem {
        public String text;
        public String desc;
        public String id;
        public boolean clickable;
        public int left, top, right, bottom, centerX, centerY;

        public NodeItem(String text, String desc, String id, boolean clickable, Rect b) {
            this.text = text;
            this.desc = desc;
            this.id = id;
            this.clickable = clickable;
            this.left = b.left;
            this.top = b.top;
            this.right = b.right;
            this.bottom = b.bottom;
            this.centerX = b.centerX();
            this.centerY = b.centerY();
        }
    }

    public static class ParsedScreen {
        public String screenType = "UNKNOWN";
        public String mapDotsSignature = "";
        public int mapDotsCount = 0;
        public String orderType = "";
        public int orderCount = 1;
        public Double km = null;
        public String kmRawText = "";
        public Double basePayK = null;
        public double extraPayK = 0.0;
        public String moneyRawText = "";
        public String pickupLabelText = "";
        public String pickupAddressText = "";
        public String dropoffLabelText = "";
        public String dropoffAddressText = "";
        public List<String> detailPickupList = new ArrayList<>();
        public boolean needsEscrow = false;
        public Integer escrowMinRequiredVnd = null;
        public Point acceptBtnPoint = null;
        public Point escrowBarPoint = null;
        public Point reloadPageBtnPoint = null;
        public Point dialogCancelBtnPoint = null;
        public String fingerprint = "";
    }

    private static final Pattern PATTERN_BUNDLE = Pattern.compile("^(\\d+)\\s*đơn hàng$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_KM = Pattern.compile("^(\\d+(?:[.,]\\d+)?)\\s*km$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_MONEY = Pattern.compile("^(\\d+(?:[.,]\\d+)?)k(?:\\s*\\+\\s*(\\d+(?:[.,]\\d+)?)k)?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_ESCROW_VND = Pattern.compile("Tiền ký quỹ tối thiểu[^0-9]*([0-9.,]+)", Pattern.CASE_INSENSITIVE);

    public static List<NodeItem> readCurrentScreenItems(AccessibilityService service) {
        if (service == null) return null;
        try {
            AccessibilityNodeInfo targetRoot = null;
            AccessibilityNodeInfo activeRoot = service.getRootInActiveWindow();
            if (activeRoot != null) {
                CharSequence pkg = activeRoot.getPackageName();
                if (pkg != null && !"com.realme.sys.touchpanel".equals(pkg.toString())) {
                    targetRoot = activeRoot;
                }
            }
            if (targetRoot == null) {
                List<AccessibilityWindowInfo> windows = service.getWindows();
                if (windows != null) {
                    for (AccessibilityWindowInfo win : windows) {
                        AccessibilityNodeInfo r = win.getRoot();
                        if (r != null && r.getPackageName() != null) {
                            String p = r.getPackageName().toString();
                            if ("vn.foody.delivery".equals(p)) {
                                targetRoot = r;
                                break;
                            } else if (!"com.realme.sys.touchpanel".equals(p) && targetRoot == null) {
                                targetRoot = r;
                            }
                        }
                    }
                }
            }
            if (targetRoot == null) return null;

            List<NodeItem> items = new ArrayList<>();
            collectNodesRecursive(targetRoot, items);
            return items;
        } catch (Exception e) {
            return null;
        }
    }

    private static void collectNodesRecursive(AccessibilityNodeInfo node, List<NodeItem> out) {
        if (node == null) return;
        try {
            CharSequence t = node.getText();
            CharSequence d = node.getContentDescription();
            String idStr = node.getViewIdResourceName();
            String txt = t != null ? t.toString().replace("\r", " ").replace("\n", " ").trim() : "";
            String desc = d != null ? d.toString().replace("\r", " ").replace("\n", " ").trim() : "";
            String id = idStr != null ? idStr : "";
            boolean clk = node.isClickable();

            if (!txt.isEmpty() || !desc.isEmpty() || !id.isEmpty() || clk) {
                Rect b = new Rect();
                node.getBoundsInScreen(b);
                out.add(new NodeItem(txt, desc, id, clk, b));
            }

            int count = node.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) {
                    collectNodesRecursive(child, out);
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static ParsedScreen parseShopeeScreen(List<NodeItem> items) {
        if (items == null || items.isEmpty()) return null;
        ParsedScreen res = new ParsedScreen();
        List<String> mapDotsList = new ArrayList<>();
        boolean isDetailView = false;
        boolean isEscrowDialog = false;

        for (int i = 0; i < items.size(); i++) {
            NodeItem it = items.get(i);
            String t = it.text;
            String d = it.desc;

            if ("Điểm đánh dấu bản đồ".equals(d)) {
                mapDotsList.add(it.left + "," + it.top + "," + it.right + "," + it.bottom);
            }
            if ("Số dư ký quỹ thấp".equals(t) || "vn.foody.delivery:id/title_message_title".equals(it.id)) {
                isEscrowDialog = true;
            }
            if (t.contains("Tiền ký quỹ tối thiểu để nhận đơn hàng này:") || "vn.foody.delivery:id/title_message_message".equals(it.id)) {
                isEscrowDialog = true;
                Matcher mEscrow = PATTERN_ESCROW_VND.matcher(t);
                if (mEscrow.find()) {
                    try {
                        String digits = mEscrow.group(1).replace(".", "").replace(",", "");
                        res.escrowMinRequiredVnd = Integer.parseInt(digits);
                    } catch (Exception ignored) {
                    }
                }
            }
            if ("vn.foody.delivery:id/negative".equals(it.id) || (isEscrowDialog && "Hủy".equals(t))) {
                res.dialogCancelBtnPoint = new Point(it.centerX, it.centerY);
            }
            if ("Chi tiết đơn hàng".equals(t)) {
                isDetailView = true;
            }
            if (t.contains("Hiện đang không có đơn thuộc dạng free-pick")) {
                res.screenType = "EMPTY_MAP";
            }
            if (t.contains("Không còn đơn hàng nào. Vui lòng tải lại trang")) {
                res.screenType = "END_OF_CARDS";
            }
            if ("Tải lại trang".equals(t)) {
                res.reloadPageBtnPoint = new Point(it.centerX, it.centerY);
            }
        }

        Collections.sort(mapDotsList);
        res.mapDotsCount = mapDotsList.size();
        StringBuilder sbDots = new StringBuilder();
        for (int i = 0; i < mapDotsList.size(); i++) {
            if (i > 0) sbDots.append(";");
            sbDots.append(mapDotsList.get(i));
        }
        res.mapDotsSignature = sbDots.toString();

        if (isEscrowDialog) {
            res.screenType = "ESCROW_DIALOG";
            return res;
        }
        if (isDetailView) {
            res.screenType = "DETAIL_SCREEN";
            boolean afterStart = false;
            boolean reachedEndLabel = false;
            for (int j = 0; j < items.size(); j++) {
                NodeItem dj = items.get(j);
                String tj = dj.text;
                if (tj == null || tj.isEmpty()) continue;
                if ("Điểm bắt đầu".equals(tj)) {
                    afterStart = true;
                    continue;
                }
                if ("Điểm kết thúc".equals(tj)) {
                    reachedEndLabel = true;
                    continue;
                }
                if ("Nhận đơn".equals(tj)) {
                    res.acceptBtnPoint = new Point(dj.centerX, dj.centerY);
                    continue;
                }
                if (afterStart && !reachedEndLabel && !"Chi tiết đơn hàng".equals(tj)) {
                    res.detailPickupList.add(tj);
                } else if (reachedEndLabel && res.dropoffAddressText.isEmpty() && !"Nhận đơn".equals(tj)) {
                    res.dropoffAddressText = tj;
                }
            }
            return res;
        }
        if ("EMPTY_MAP".equals(res.screenType) || "END_OF_CARDS".equals(res.screenType)) {
            return res;
        }

        int pickupLabelIdx = -1;
        int dropoffLabelIdx = -1;

        for (int k = 0; k < items.size(); k++) {
            NodeItem node = items.get(k);
            String txt = node.text;
            if (txt == null || txt.isEmpty() || node.top < 1450) continue;

            if ("Shopee".equals(txt)) {
                res.orderType = "SHOPEE";
                continue;
            }
            if ("Delivery".equals(txt)) {
                res.orderType = "FOOD";
                continue;
            }

            Matcher mBundle = PATTERN_BUNDLE.matcher(txt);
            if (mBundle.matches()) {
                try {
                    res.orderCount = Integer.parseInt(mBundle.group(1));
                } catch (Exception ignored) {
                }
                continue;
            }

            Matcher mKm = PATTERN_KM.matcher(txt);
            if (mKm.matches() && res.km == null) {
                try {
                    res.km = Double.parseDouble(mKm.group(1).replace(",", "."));
                    res.kmRawText = txt;
                } catch (Exception ignored) {
                }
                continue;
            }

            Matcher mMoney = PATTERN_MONEY.matcher(txt);
            if (mMoney.matches() && res.basePayK == null) {
                try {
                    res.basePayK = Double.parseDouble(mMoney.group(1).replace(",", "."));
                    res.extraPayK = (mMoney.group(2) != null) ? Double.parseDouble(mMoney.group(2).replace(",", ".")) : 0.0;
                    res.moneyRawText = txt;
                } catch (Exception ignored) {
                }
                continue;
            }

            if (txt.startsWith("Lấy hàng:") || txt.startsWith("Điểm bắt đầu:")) {
                res.pickupLabelText = txt;
                pickupLabelIdx = k;
                continue;
            }
            if ((txt.startsWith("Giao:") && node.left < 300 && node.top > 1900) || txt.startsWith("Điểm kết thúc:")) {
                res.dropoffLabelText = txt;
                dropoffLabelIdx = k;
                continue;
            }
            if ("Nhận đơn".equals(txt)) {
                res.acceptBtnPoint = new Point(node.centerX, node.centerY);
                res.needsEscrow = false;
                continue;
            }
            if (txt.contains("Bạn cần nạp thêm tiền ký quỹ")) {
                res.escrowBarPoint = new Point(node.centerX, node.centerY);
                res.needsEscrow = true;
            }
        }

        if (pickupLabelIdx != -1) {
            int limitIdx = (dropoffLabelIdx != -1) ? dropoffLabelIdx : items.size();
            for (int p = pickupLabelIdx + 1; p < limitIdx; p++) {
                String pt = items.get(p).text;
                if (pt == null || pt.isEmpty() || pt.startsWith("Trả:") || pt.contains("₫")) continue;
                res.pickupAddressText = pt;
                break;
            }
        }
        if (dropoffLabelIdx != -1) {
            for (int q = dropoffLabelIdx + 1; q < items.size(); q++) {
                String qt = items.get(q).text;
                if (qt == null || qt.isEmpty() || qt.startsWith("Thu:") || "***".equals(qt) || qt.contains("₫")) continue;
                if ("Nhận đơn".equals(qt) || qt.contains("Bạn cần nạp thêm tiền ký quỹ")) break;
                res.dropoffAddressText = qt;
                break;
            }
        }

        if (res.basePayK != null && res.km != null) {
            res.screenType = "OUTER_CARD";
            res.fingerprint = res.moneyRawText + "|" + res.kmRawText + "|" + res.pickupLabelText + "|" + res.pickupAddressText;
        }
        return res;
    }

    public static boolean checkDynamicRulesList(Double actualValue, List<AppConfig.DynamicRule> rules, boolean useNormalToo) {
        if (rules == null || rules.isEmpty()) return true;
        List<AppConfig.DynamicRule> active = new ArrayList<>();
        for (AppConfig.DynamicRule r : rules) {
            if (r.pri || (useNormalToo && r.norm)) {
                active.add(r);
            }
        }
        if (active.isEmpty()) return true;
        if (actualValue == null || Double.isNaN(actualValue)) return false;
        for (AppConfig.DynamicRule r : active) {
            if ("ge".equals(r.op) && actualValue >= r.val) return true;
            if ("le".equals(r.op) && actualValue <= r.val) return true;
        }
        return false;
    }

    public static boolean checkBundleRules(int orderCount, Map<String, AppConfig.TierState> bundleMap, boolean useNormalToo) {
        if (bundleMap == null || bundleMap.isEmpty()) return true;
        boolean anyActive = false;
        for (int i = 0; i < AppConfig.BUNDLE_KEYS.length; i++) {
            String key = AppConfig.BUNDLE_KEYS[i];
            AppConfig.TierState st = bundleMap.get(key);
            if (st != null && (st.pri || (useNormalToo && st.norm))) {
                anyActive = true;
                int targetCount = AppConfig.BUNDLE_COUNTS[i];
                String mode = AppConfig.BUNDLE_MODES[i];
                if ("exact".equals(mode) && orderCount == targetCount) return true;
                if ("ge".equals(mode) && orderCount >= targetCount) return true;
            }
        }
        return !anyActive;
    }

    public static boolean checkFinalDropoffArea(String finalDropoffText, AppConfig cfg, boolean useNormalToo) {
        String addrLower = (finalDropoffText != null ? finalDropoffText : "").toLowerCase(Locale.ROOT);
        for (Map.Entry<String, Boolean> en : cfg.avoidAreas.entrySet()) {
            if (Boolean.TRUE.equals(en.getValue()) && addrLower.contains(en.getKey().toLowerCase(Locale.ROOT))) {
                return false;
            }
        }
        List<String> activePrefs = new ArrayList<>();
        for (Map.Entry<String, AppConfig.TierState> en : cfg.prefAreas.entrySet()) {
            AppConfig.TierState st = en.getValue();
            if (st != null && (st.pri || (useNormalToo && st.norm))) {
                activePrefs.add(en.getKey());
            }
        }
        if (activePrefs.isEmpty()) return true;
        for (String area : activePrefs) {
            if (addrLower.contains(area.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    public static boolean isBadShopMatch(String shopLabel, String shopAddr, AppConfig cfg) {
        if (cfg.badShops == null || cfg.badShops.isEmpty()) return false;
        String cleanLabel = shopLabel != null ? shopLabel.trim() : "";
        String cleanAddr = shopAddr != null ? shopAddr.trim() : "";
        for (AppConfig.BadShopItem item : cfg.badShops) {
            String bName = item.name != null ? item.name.trim() : "";
            String bAddr = item.addr != null ? item.addr.trim() : "";
            if (!bName.isEmpty() && !"Lấy hàng: ***".equals(bName) && !"Điểm bắt đầu: ***".equals(bName) && !bAddr.isEmpty()) {
                if (cleanLabel.equals(bName) && cleanAddr.equals(bAddr)) return true;
                if (cleanAddr.equals(bAddr)) return true;
            } else if (!bAddr.isEmpty()) {
                if (cleanAddr.equals(bAddr)) return true;
            } else if (!bName.isEmpty()) {
                if (cleanLabel.equals(bName) || cleanAddr.equals(bName)) return true;
            }
        }
        return false;
    }

    public static boolean evaluateOuterOrderCard(ParsedScreen sc, AppConfig cfg, boolean useNormalToo) {
        if ("FOOD".equals(cfg.runMode)) {
            if (!"FOOD".equals(sc.orderType)) return false;
            if (!checkDynamicRulesList(sc.km, cfg.foodKmRules, useNormalToo)) return false;
            if (isBadShopMatch(sc.pickupLabelText, sc.pickupAddressText, cfg)) return false;
            return true;
        }
        if (!"SHOPEE".equals(sc.orderType)) return false;
        if (!checkBundleRules(sc.orderCount, cfg.bundleRules, useNormalToo)) return false;
        if (!checkDynamicRulesList(sc.km, cfg.shopeeKmRules, useNormalToo)) return false;
        if (!checkDynamicRulesList(sc.basePayK, cfg.shopeeBasePayRules, useNormalToo)) return false;
        if (!checkDynamicRulesList(sc.extraPayK, cfg.shopeeExtraPayRules, useNormalToo)) return false;
        if (!checkFinalDropoffArea(sc.dropoffAddressText, cfg, useNormalToo)) return false;
        if (isBadShopMatch(sc.pickupLabelText, sc.pickupAddressText, cfg)) return false;
        return true;
    }
}
