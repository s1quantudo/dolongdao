package com.realme.sys.touchpanel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainPanelActivity extends Activity {

    private AppConfig cfg;
    private int currentTabIdx = 0;

    private TextView tvHeaderSub;
    private Button btnModeShopee;
    private Button btnModeFood;
    private EditText inpPriMinutes;
    private EditText inpMaxEscrowK;

    private Button[] tabButtons = new Button[4];
    private LinearLayout contentContainer;

    private EditText inpCoordReloadX, inpCoordReloadY;
    private EditText inpCoordExpandX, inpCoordExpandY;
    private EditText inpCoordBackX, inpCoordBackY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.parseColor("#EE4D2D"));

        cfg = AppConfig.load(this);
        buildMainLayout();
        switchTab(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        cfg = AppConfig.load(this);
        if (inpPriMinutes != null) {
            inpPriMinutes.setText(String.valueOf(cfg.priorityMinutes));
        }
        if (inpMaxEscrowK != null) {
            inpMaxEscrowK.setText(String.valueOf(cfg.maxEscrowMinK));
        }
        switchTab(currentTabIdx);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()
        );
    }

    private GradientDrawable roundBg(String hexColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(hexColor));
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }

    private void captureTopInputs() {
        if (inpPriMinutes != null) {
            try {
                int pm = Integer.parseInt(inpPriMinutes.getText().toString().trim());
                if (pm >= 0) cfg.priorityMinutes = pm;
            } catch (Exception ignored) {
            }
        }
        if (inpMaxEscrowK != null) {
            try {
                int me = Integer.parseInt(inpMaxEscrowK.getText().toString().trim());
                if (me >= 0) cfg.maxEscrowMinK = me;
            } catch (Exception ignored) {
            }
        }
        if (inpCoordReloadX != null) {
            try { cfg.reloadX = Integer.parseInt(inpCoordReloadX.getText().toString().trim()); } catch (Exception ignored) {}
            try { cfg.reloadY = Integer.parseInt(inpCoordReloadY.getText().toString().trim()); } catch (Exception ignored) {}
            try { cfg.expandX = Integer.parseInt(inpCoordExpandX.getText().toString().trim()); } catch (Exception ignored) {}
            try { cfg.expandY = Integer.parseInt(inpCoordExpandY.getText().toString().trim()); } catch (Exception ignored) {}
            try { cfg.backX = Integer.parseInt(inpCoordBackX.getText().toString().trim()); } catch (Exception ignored) {}
            try { cfg.backY = Integer.parseInt(inpCoordBackY.getText().toString().trim()); } catch (Exception ignored) {}
        }
        cfg.save(this);
    }

    private void buildMainLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F1F5F9"));

        // 1. Header Bar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(Color.parseColor("#EE4D2D"));
        header.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout headerTitleCol = new LinearLayout(this);
        headerTitleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lpTitleCol = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        headerTitleCol.setLayoutParams(lpTitleCol);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("DOLONGDAO - NATIVE v1.0");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        headerTitleCol.addView(tvTitle);

        tvHeaderSub = new TextView(this);
        tvHeaderSub.setText("App Android gốc 100% (Không AutoJs6)");
        tvHeaderSub.setTextColor(Color.parseColor("#FFE4DE"));
        tvHeaderSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        headerTitleCol.addView(tvHeaderSub);
        header.addView(headerTitleCol);

        Button btnRunHud = new Button(this);
        btnRunHud.setText("BẬT THANH NỔI");
        btnRunHud.setAllCaps(false);
        btnRunHud.setTextColor(Color.parseColor("#EE4D2D"));
        btnRunHud.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnRunHud.setTypeface(Typeface.DEFAULT_BOLD);
        btnRunHud.setBackground(roundBg("#FFFFFF", 8));
        LinearLayout.LayoutParams lpBtnRun = new LinearLayout.LayoutParams(dp(120), dp(38));
        btnRunHud.setLayoutParams(lpBtnRun);
        btnRunHud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchStealthFloatingHud();
            }
        });
        header.addView(btnRunHud);
        root.addView(header);

        // 2. Top Mode & Timer Card
        LinearLayout topCard = new LinearLayout(this);
        topCard.setOrientation(LinearLayout.VERTICAL);
        topCard.setBackground(roundBg("#FFFFFF", 8));
        topCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lpTopCard = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpTopCard.setMargins(dp(10), dp(6), dp(10), dp(4));
        topCard.setLayoutParams(lpTopCard);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvModeLbl = new TextView(this);
        tvModeLbl.setText("CHẾ ĐỘ:");
        tvModeLbl.setTextColor(Color.parseColor("#1E293B"));
        tvModeLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tvModeLbl.setTypeface(Typeface.DEFAULT_BOLD);
        tvModeLbl.setPadding(0, 0, dp(6), 0);
        modeRow.addView(tvModeLbl);

        btnModeShopee = new Button(this);
        btnModeShopee.setText("🛍️ SHOPEE HỎA TỐC");
        btnModeShopee.setAllCaps(false);
        btnModeShopee.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnModeShopee.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lpM1 = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lpM1.rightMargin = dp(4);
        btnModeShopee.setLayoutParams(lpM1);

        btnModeFood = new Button(this);
        btnModeFood.setText("🍔 ĐƠN FOOD");
        btnModeFood.setAllCaps(false);
        btnModeFood.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnModeFood.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lpM2 = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lpM2.leftMargin = dp(4);
        btnModeFood.setLayoutParams(lpM2);

        btnModeShopee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureTopInputs();
                cfg.runMode = "SHOPEE";
                cfg.save(MainPanelActivity.this);
                updateModeButtonsStyle();
                switchTab(currentTabIdx);
            }
        });
        btnModeFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureTopInputs();
                cfg.runMode = "FOOD";
                cfg.save(MainPanelActivity.this);
                updateModeButtonsStyle();
                switchTab(currentTabIdx);
            }
        });

        modeRow.addView(btnModeShopee);
        modeRow.addView(btnModeFood);
        topCard.addView(modeRow);

        LinearLayout timerRow = new LinearLayout(this);
        timerRow.setOrientation(LinearLayout.HORIZONTAL);
        timerRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lpTimer = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpTimer.topMargin = dp(6);
        timerRow.setLayoutParams(lpTimer);

        TextView tvPri = new TextView(this);
        tvPri.setText("Chạy Ưu Tiên: ");
        tvPri.setTextColor(Color.parseColor("#334155"));
        tvPri.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        timerRow.addView(tvPri);

        inpPriMinutes = new EditText(this);
        inpPriMinutes.setInputType(InputType.TYPE_CLASS_NUMBER);
        inpPriMinutes.setText(String.valueOf(cfg.priorityMinutes));
        inpPriMinutes.setTextColor(Color.parseColor("#EE4D2D"));
        inpPriMinutes.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        inpPriMinutes.setTypeface(Typeface.DEFAULT_BOLD);
        inpPriMinutes.setGravity(Gravity.CENTER);
        inpPriMinutes.setLayoutParams(new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT));
        timerRow.addView(inpPriMinutes);

        TextView tvMid = new TextView(this);
        tvMid.setText(" phút | Quỹ tối đa: ");
        tvMid.setTextColor(Color.parseColor("#334155"));
        tvMid.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        timerRow.addView(tvMid);

        inpMaxEscrowK = new EditText(this);
        inpMaxEscrowK.setInputType(InputType.TYPE_CLASS_NUMBER);
        inpMaxEscrowK.setText(String.valueOf(cfg.maxEscrowMinK));
        inpMaxEscrowK.setTextColor(Color.parseColor("#15803D"));
        inpMaxEscrowK.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        inpMaxEscrowK.setTypeface(Typeface.DEFAULT_BOLD);
        inpMaxEscrowK.setGravity(Gravity.CENTER);
        inpMaxEscrowK.setLayoutParams(new LinearLayout.LayoutParams(dp(68), ViewGroup.LayoutParams.WRAP_CONTENT));
        timerRow.addView(inpMaxEscrowK);

        TextView tvK = new TextView(this);
        tvK.setText("k");
        tvK.setTextColor(Color.parseColor("#334155"));
        tvK.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tvK.setTypeface(Typeface.DEFAULT_BOLD);
        timerRow.addView(tvK);

        topCard.addView(timerRow);
        root.addView(topCard);

        // 3. Tab Bar (4 Tabs)
        LinearLayout tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(Color.WHITE);
        tabBar.setPadding(dp(6), dp(4), dp(6), dp(4));

        String[] tabTitles = new String[]{"Bộ Lọc Đơn", "Khu Vực Giao", "Shop Khê", "Tọa Độ 🎯"};
        for (int i = 0; i < 4; i++) {
            final int tabIdx = i;
            Button b = new Button(this);
            b.setText(tabTitles[i]);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setPadding(dp(2), dp(2), dp(2), dp(2));
            LinearLayout.LayoutParams lpTab = new LinearLayout.LayoutParams(0, dp(36), 1f);
            lpTab.setMargins(dp(2), 0, dp(2), 0);
            b.setLayoutParams(lpTab);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    captureTopInputs();
                    switchTab(tabIdx);
                }
            });
            tabButtons[i] = b;
            tabBar.addView(b);
        }
        root.addView(tabBar);

        // 4. Scrollable Content Area
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ));
        contentContainer = new LinearLayout(this);
        contentContainer.setOrientation(LinearLayout.VERTICAL);
        contentContainer.setPadding(dp(10), dp(8), dp(10), dp(28));
        sv.addView(contentContainer);
        root.addView(sv);

        updateModeButtonsStyle();
        setContentView(root);
    }

    private void updateModeButtonsStyle() {
        if ("FOOD".equals(cfg.runMode)) {
            btnModeFood.setBackground(roundBg("#EE4D2D", 6));
            btnModeFood.setTextColor(Color.WHITE);
            btnModeShopee.setBackground(roundBg("#E2E8F0", 6));
            btnModeShopee.setTextColor(Color.parseColor("#334155"));
            tvHeaderSub.setText("Chế độ: ĐƠN FOOD | Bấm [BẬT THANH NỔI] sẽ đóng hẳn cửa sổ này");
        } else {
            btnModeShopee.setBackground(roundBg("#EE4D2D", 6));
            btnModeShopee.setTextColor(Color.WHITE);
            btnModeFood.setBackground(roundBg("#E2E8F0", 6));
            btnModeFood.setTextColor(Color.parseColor("#334155"));
            tvHeaderSub.setText("Chế độ: SHOPEE HỎA TỐC | Bấm [BẬT THANH NỔI] sẽ đóng hẳn cửa sổ này");
        }
    }

    private void switchTab(int idx) {
        currentTabIdx = idx;
        for (int i = 0; i < 4; i++) {
            if (i == idx) {
                tabButtons[i].setBackground(roundBg("#EE4D2D", 6));
                tabButtons[i].setTextColor(Color.WHITE);
            } else {
                tabButtons[i].setBackground(roundBg("#F1F5F9", 6));
                tabButtons[i].setTextColor(Color.parseColor("#64748B"));
            }
        }
        contentContainer.removeAllViews();
        inpCoordReloadX = null;

        if (idx == 0) {
            renderFilterTab();
        } else if (idx == 1) {
            renderGeographyTab();
        } else if (idx == 2) {
            renderBadShopsTab();
        } else {
            renderCoordsTab();
        }
    }

    private void renderFilterTab() {
        if ("FOOD".equals(cfg.runMode)) {
            addDynamicRuleCard(
                "1. BỘ LỌC KILOMET (ĐƠN FOOD)",
                "Thêm/xóa tùy ý. Tích [Ưu tiên] chạy trong X phút đầu, sau đó mở rộng sang [Thường].",
                "km",
                cfg.foodKmRules
            );
        } else {
            addDynamicRuleCard(
                "1. BỘ LỌC KILOMET (KM)",
                "Từ X km trở lên (>=) hoặc trở xuống (<=). Không tích = Không giới hạn Km.",
                "km",
                cfg.shopeeKmRules
            );
            addBundleSectionCard();
            addDynamicRuleCard(
                "3. SỐ TIỀN GỐC (CƯỚC CƠ BẢN - NGHÌN ĐỒNG)",
                "Tách biệt tuyệt đối với Tiền phụ. VD: 72.5k + 18k thì chỉ xét 72.5k.",
                "k",
                cfg.shopeeBasePayRules
            );
            addDynamicRuleCard(
                "4. SỐ TIỀN PHỤ (+THƯỞNG / CAO ĐIỂM - NGHÌN ĐỒNG)",
                "Xét riêng số tiền đứng sau dấu '+'. Không tích = Không bắt buộc có tiền phụ.",
                "k",
                cfg.shopeeExtraPayRules
            );
        }
    }

    private void addDynamicRuleCard(String title, String sub, final String unit, final List<AppConfig.DynamicRule> rules) {
        LinearLayout card = createWhiteCard();

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvT = new TextView(this);
        tvT.setText(title);
        tvT.setTextColor(Color.parseColor("#1E293B"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        titleCol.addView(tvT);

        TextView tvS = new TextView(this);
        tvS.setText(sub);
        tvS.setTextColor(Color.parseColor("#64748B"));
        tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        titleCol.addView(tvS);
        topRow.addView(titleCol);

        Button btnAdd = new Button(this);
        btnAdd.setText("+ THÊM");
        btnAdd.setAllCaps(false);
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnAdd.setTypeface(Typeface.DEFAULT_BOLD);
        btnAdd.setBackground(roundBg("#0284C7", 6));
        btnAdd.setLayoutParams(new LinearLayout.LayoutParams(dp(74), dp(34)));
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptAddDynamicRule(unit, rules);
            }
        });
        topRow.addView(btnAdd);
        card.addView(topRow);

        // Table Header
        LinearLayout tblHead = new LinearLayout(this);
        tblHead.setOrientation(LinearLayout.HORIZONTAL);
        tblHead.setBackgroundColor(Color.parseColor("#F8FAFC"));
        tblHead.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lpHead = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpHead.topMargin = dp(6);
        tblHead.setLayoutParams(lpHead);

        tblHead.addView(createColHeader("Điều kiện lọc", "#475569", 0, 1f, Gravity.START));
        tblHead.addView(createColHeader("Ưu tiên", "#EA580C", 64, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Thường", "#0284C7", 64, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Xóa", "#DC2626", 42, 0f, Gravity.CENTER));
        card.addView(tblHead);

        for (int i = 0; i < rules.size(); i++) {
            final int idx = i;
            final AppConfig.DynamicRule r = rules.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(2), dp(4), dp(2));

            TextView tvName = new TextView(this);
            tvName.setText(r.formatLabel(unit));
            tvName.setTextColor(Color.parseColor("#1E293B"));
            tvName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tvName);

            CheckBox cbPri = new CheckBox(this);
            cbPri.setChecked(r.pri);
            cbPri.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    r.pri = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbPri, 64));

            CheckBox cbNorm = new CheckBox(this);
            cbNorm.setChecked(r.norm);
            cbNorm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    r.norm = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbNorm, 64));

            Button btnDel = new Button(this);
            btnDel.setText("✕");
            btnDel.setTextColor(Color.parseColor("#DC2626"));
            btnDel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            btnDel.setBackgroundColor(Color.TRANSPARENT);
            btnDel.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(34)));
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    rules.remove(idx);
                    cfg.save(MainPanelActivity.this);
                    switchTab(currentTabIdx);
                }
            });
            row.addView(btnDel);
            card.addView(row);
        }

        contentContainer.addView(card);
    }

    private void promptAddDynamicRule(final String unit, final List<AppConfig.DynamicRule> targetRules) {
        final String[] options = new String[]{
            "Từ X " + unit + " trở lên ( >= X )",
            "Từ X " + unit + " trở xuống ( <= X )"
        };
        new AlertDialog.Builder(this)
            .setTitle("Chọn loại điều kiện " + unit + ":")
            .setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    final String opType = (which == 0) ? "ge" : "le";
                    String title = "ge".equals(opType)
                        ? ("Từ bao nhiêu " + unit + " trở lên?")
                        : ("Từ bao nhiêu " + unit + " trở xuống?");

                    final EditText input = new EditText(MainPanelActivity.this);
                    input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    input.setHint("Nhập con số...");

                    new AlertDialog.Builder(MainPanelActivity.this)
                        .setTitle(title)
                        .setView(input)
                        .setPositiveButton("THÊM", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                try {
                                    String raw = input.getText().toString().replace(",", ".").trim();
                                    double val = Double.parseDouble(raw);
                                    if (val < 0) return;
                                    targetRules.add(new AppConfig.DynamicRule(
                                        "rule_" + System.currentTimeMillis(), opType, val, false, false
                                    ));
                                    cfg.save(MainPanelActivity.this);
                                    switchTab(currentTabIdx);
                                } catch (Exception e) {
                                    Toast.makeText(MainPanelActivity.this, "Số không hợp lệ!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("HỦY", null)
                        .show();
                }
            })
            .show();
    }

    private void addBundleSectionCard() {
        LinearLayout card = createWhiteCard();

        TextView tvT = new TextView(this);
        tvT.setText("2. SỐ LƯỢNG ĐƠN (SOLO / CHÙM ĐƠN)");
        tvT.setTextColor(Color.parseColor("#1E293B"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(tvT);

        TextView tvS = new TextView(this);
        tvS.setText("Không tích ô nào = Nhận mọi số lượng đơn. Có tích = Chỉ nhận loại đã tích.");
        tvS.setTextColor(Color.parseColor("#64748B"));
        tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        card.addView(tvS);

        LinearLayout tblHead = new LinearLayout(this);
        tblHead.setOrientation(LinearLayout.HORIZONTAL);
        tblHead.setBackgroundColor(Color.parseColor("#F8FAFC"));
        tblHead.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lpHead = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpHead.topMargin = dp(6);
        tblHead.setLayoutParams(lpHead);

        tblHead.addView(createColHeader("Loại đơn / Chùm đơn", "#475569", 0, 1f, Gravity.START));
        tblHead.addView(createColHeader("Ưu tiên", "#EA580C", 72, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Thường", "#0284C7", 72, 0f, Gravity.CENTER));
        card.addView(tblHead);

        for (int i = 0; i < AppConfig.BUNDLE_KEYS.length; i++) {
            final String key = AppConfig.BUNDLE_KEYS[i];
            String label = AppConfig.BUNDLE_LABELS[i];
            AppConfig.TierState st = cfg.bundleRules.get(key);
            if (st == null) {
                st = new AppConfig.TierState(false, false);
                cfg.bundleRules.put(key, st);
            }
            final AppConfig.TierState finalSt = st;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(2), dp(4), dp(2));

            TextView tvL = new TextView(this);
            tvL.setText(label);
            tvL.setTextColor(Color.parseColor("#1E293B"));
            tvL.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvL.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tvL);

            CheckBox cbP = new CheckBox(this);
            cbP.setChecked(finalSt.pri);
            cbP.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.pri = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbP, 72));

            CheckBox cbN = new CheckBox(this);
            cbN.setChecked(finalSt.norm);
            cbN.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.norm = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbN, 72));
            card.addView(row);
        }

        contentContainer.addView(card);
    }

    private void renderGeographyTab() {
        LinearLayout card = createWhiteCard();

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvT = new TextView(this);
        tvT.setText("PHÂN VÙNG ĐỊA LÝ HÀ NỘI (ĐIỂM GIAO CUỐI)");
        tvT.setTextColor(Color.parseColor("#1E293B"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        titleCol.addView(tvT);

        TextView tvS = new TextView(this);
        tvS.setText("12 Quận nội thành + 6 Huyện lân cận xếp trên; các Huyện xa xếp dưới.");
        tvS.setTextColor(Color.parseColor("#64748B"));
        tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        titleCol.addView(tvS);
        topRow.addView(titleCol);

        Button btnClear = new Button(this);
        btnClear.setText("Bỏ tích hết");
        btnClear.setAllCaps(false);
        btnClear.setTextColor(Color.parseColor("#DC2626"));
        btnClear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClear.setBackgroundColor(Color.TRANSPARENT);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cfg.prefAreas.clear();
                cfg.avoidAreas.clear();
                cfg.save(MainPanelActivity.this);
                switchTab(1);
            }
        });
        topRow.addView(btnClear);
        card.addView(topRow);

        LinearLayout tblHead = new LinearLayout(this);
        tblHead.setOrientation(LinearLayout.HORIZONTAL);
        tblHead.setBackgroundColor(Color.parseColor("#F8FAFC"));
        tblHead.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lpHead = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpHead.topMargin = dp(6);
        tblHead.setLayoutParams(lpHead);

        tblHead.addView(createColHeader("Quận / Huyện", "#475569", 0, 1f, Gravity.START));
        tblHead.addView(createColHeader("Ưu tiên", "#EA580C", 62, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Thường", "#0284C7", 62, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("NÉ", "#DC2626", 62, 0f, Gravity.CENTER));
        card.addView(tblHead);

        addAreaGroupHeader(card, "★ 12 QUẬN NỘI THÀNH & 6 HUYỆN LÂN CẬN", "#EFF6FF", "#1D4ED8");
        addAreaRows(card, AppConfig.PRIORITY_HANOI_AREAS);

        addAreaGroupHeader(card, "• CÁC HUYỆN / THỊ XÃ XA XÔI", "#F1F5F9", "#475569");
        addAreaRows(card, AppConfig.OUTER_HANOI_AREAS);

        contentContainer.addView(card);
    }

    private void addAreaGroupHeader(LinearLayout parent, String text, String bgHex, String txtHex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setBackgroundColor(Color.parseColor(bgHex));
        tv.setTextColor(Color.parseColor(txtHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = dp(4);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void addAreaRows(LinearLayout parent, String[] areas) {
        for (final String area : areas) {
            AppConfig.TierState st = cfg.prefAreas.get(area);
            if (st == null) {
                st = new AppConfig.TierState(false, false);
                cfg.prefAreas.put(area, st);
            }
            final AppConfig.TierState finalSt = st;
            boolean isAvoid = Boolean.TRUE.equals(cfg.avoidAreas.get(area));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(1), dp(4), dp(1));

            TextView tvA = new TextView(this);
            tvA.setText(area);
            tvA.setTextColor(Color.parseColor("#1E293B"));
            tvA.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvA.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tvA);

            final CheckBox cbPri = new CheckBox(this);
            final CheckBox cbNorm = new CheckBox(this);
            final CheckBox cbAvoid = new CheckBox(this);

            cbPri.setChecked(finalSt.pri);
            cbNorm.setChecked(finalSt.norm);
            cbAvoid.setChecked(isAvoid);

            cbPri.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.pri = isChecked;
                    if (isChecked) {
                        cfg.avoidAreas.remove(area);
                        cbAvoid.setChecked(false);
                    }
                    cfg.save(MainPanelActivity.this);
                }
            });

            cbNorm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.norm = isChecked;
                    if (isChecked) {
                        cfg.avoidAreas.remove(area);
                        cbAvoid.setChecked(false);
                    }
                    cfg.save(MainPanelActivity.this);
                }
            });

            cbAvoid.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        cfg.avoidAreas.put(area, true);
                        finalSt.pri = false;
                        finalSt.norm = false;
                        cbPri.setChecked(false);
                        cbNorm.setChecked(false);
                    } else {
                        cfg.avoidAreas.remove(area);
                    }
                    cfg.save(MainPanelActivity.this);
                }
            });

            row.addView(wrapCenter(cbPri, 62));
            row.addView(wrapCenter(cbNorm, 62));
            row.addView(wrapCenter(cbAvoid, 62));
            parent.addView(row);
        }
    }

    private void renderBadShopsTab() {
        LinearLayout addCard = createWhiteCard();

        TextView tvT = new TextView(this);
        tvT.setText("DANH SÁCH SHOP / QUÁN KHÊ (CHUẨN 100% KÝ TỰ)");
        tvT.setTextColor(Color.parseColor("#EE4D2D"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        addCard.addView(tvT);

        TextView tvSub = new TextView(this);
        tvSub.setText("• Khi đang bật thanh nổi, bấm nút [📌] để tự động trích xuất Tên + Địa chỉ Shop/Quán (hỗ trợ chọn từng Shop trong Đơn Chùm).\n• Hoặc nhập thủ công bên dưới:");
        tvSub.setTextColor(Color.parseColor("#475569"));
        tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvSub.setPadding(0, dp(4), 0, dp(6));
        addCard.addView(tvSub);

        final EditText inpName = new EditText(this);
        inpName.setHint("Tên Shop/Quán (hoặc để trống)");
        inpName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        addCard.addView(inpName);

        LinearLayout addrRow = new LinearLayout(this);
        addrRow.setOrientation(LinearLayout.HORIZONTAL);
        addrRow.setGravity(Gravity.CENTER_VERTICAL);

        final EditText inpAddr = new EditText(this);
        inpAddr.setHint("Chuỗi địa chỉ lấy hàng chính xác 100%...");
        inpAddr.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        inpAddr.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        addrRow.addView(inpAddr);

        Button btnAdd = new Button(this);
        btnAdd.setText("THÊM");
        btnAdd.setAllCaps(false);
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnAdd.setTypeface(Typeface.DEFAULT_BOLD);
        btnAdd.setBackground(roundBg("#EE4D2D", 6));
        LinearLayout.LayoutParams lpAdd = new LinearLayout.LayoutParams(dp(72), dp(38));
        lpAdd.leftMargin = dp(6);
        btnAdd.setLayoutParams(lpAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = inpName.getText().toString().trim();
                String a = inpAddr.getText().toString().trim();
                if (n.isEmpty() && a.isEmpty()) {
                    Toast.makeText(MainPanelActivity.this, "Hãy nhập Tên hoặc Địa chỉ Shop!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (cfg.addShopToBlacklist(MainPanelActivity.this, n, a)) {
                    inpName.setText("");
                    inpAddr.setText("");
                    switchTab(2);
                    Toast.makeText(MainPanelActivity.this, "Đã thêm vào Blacklist!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainPanelActivity.this, "Shop này đã có sẵn!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        addrRow.addView(btnAdd);
        addCard.addView(addrRow);
        contentContainer.addView(addCard);

        LinearLayout listCard = createWhiteCard();
        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvCount = new TextView(this);
        tvCount.setText("Đang lưu: " + cfg.badShops.size() + " Shop/Quán khê");
        tvCount.setTextColor(Color.parseColor("#1E293B"));
        tvCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvCount.setTypeface(Typeface.DEFAULT_BOLD);
        tvCount.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        headRow.addView(tvCount);

        Button btnClearAll = new Button(this);
        btnClearAll.setText("Xóa hết");
        btnClearAll.setAllCaps(false);
        btnClearAll.setTextColor(Color.parseColor("#DC2626"));
        btnClearAll.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClearAll.setBackgroundColor(Color.TRANSPARENT);
        btnClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cfg.badShops.clear();
                cfg.save(MainPanelActivity.this);
                switchTab(2);
            }
        });
        headRow.addView(btnClearAll);
        listCard.addView(headRow);

        for (int i = 0; i < cfg.badShops.size(); i++) {
            final int idx = i;
            AppConfig.BadShopItem item = cfg.badShops.get(i);

            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setBackgroundColor(Color.parseColor("#F8FAFC"));
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            LinearLayout.LayoutParams lpR = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lpR.topMargin = dp(4);
            r.setLayoutParams(lpR);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvSn = new TextView(this);
            tvSn.setText((i + 1) + ". " + ((item.name != null && !item.name.isEmpty()) ? item.name : "Shop Shopee (Ẩn tên ***)"));
            tvSn.setTextColor(Color.parseColor("#0F172A"));
            tvSn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvSn.setTypeface(Typeface.DEFAULT_BOLD);
            col.addView(tvSn);

            TextView tvSa = new TextView(this);
            tvSa.setText(item.addr);
            tvSa.setTextColor(Color.parseColor("#475569"));
            tvSa.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            col.addView(tvSa);
            r.addView(col);

            Button btnDel = new Button(this);
            btnDel.setText("Xóa");
            btnDel.setAllCaps(false);
            btnDel.setTextColor(Color.parseColor("#DC2626"));
            btnDel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            btnDel.setBackgroundColor(Color.TRANSPARENT);
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cfg.badShops.remove(idx);
                    cfg.save(MainPanelActivity.this);
                    switchTab(2);
                }
            });
            r.addView(btnDel);
            listCard.addView(r);
        }

        contentContainer.addView(listCard);
    }

    private void renderCoordsTab() {
        LinearLayout card = createWhiteCard();

        TextView tvT = new TextView(this);
        tvT.setText("🎯 ĐỊNH VỊ TỌA ĐỘ (MẶC ĐỊNH REALME NEO 7 1080x2376)");
        tvT.setTextColor(Color.parseColor("#EE4D2D"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(tvT);

        Button btnCross = new Button(this);
        btnCross.setText("🎯 BẬT 3 TÂM NGẮM KÉO THẢ TỌA ĐỘ");
        btnCross.setAllCaps(false);
        btnCross.setTextColor(Color.WHITE);
        btnCross.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        btnCross.setTypeface(Typeface.DEFAULT_BOLD);
        btnCross.setBackground(roundBg("#2563EB", 8));
        LinearLayout.LayoutParams lpCross = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42)
        );
        lpCross.topMargin = dp(8);
        lpCross.bottomMargin = dp(8);
        btnCross.setLayoutParams(lpCross);
        btnCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureTopInputs();
                TouchAssistService svc = TouchAssistService.getInstance();
                if (svc == null) {
                    Toast.makeText(MainPanelActivity.this, "Hãy bật Trợ năng cho DolongDAO trước!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    return;
                }
                svc.showCrosshairTargets();
            }
        });
        card.addView(btnCross);

        inpCoordReloadX = createCoordInput(cfg.reloadX);
        inpCoordReloadY = createCoordInput(cfg.reloadY);
        card.addView(createCoordRow("Nút Load Map (X, Y):", inpCoordReloadX, inpCoordReloadY));

        inpCoordExpandX = createCoordInput(cfg.expandX);
        inpCoordExpandY = createCoordInput(cfg.expandY);
        card.addView(createCoordRow("Nút Mở rộng (X, Y):", inpCoordExpandX, inpCoordExpandY));

        inpCoordBackX = createCoordInput(cfg.backX);
        inpCoordBackY = createCoordInput(cfg.backY);
        card.addView(createCoordRow("Nút Quay lại (X, Y):", inpCoordBackX, inpCoordBackY));

        Button btnSave = new Button(this);
        btnSave.setText("LƯU THÔNG SỐ TỌA ĐỘ");
        btnSave.setAllCaps(false);
        btnSave.setTextColor(Color.WHITE);
        btnSave.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        btnSave.setTypeface(Typeface.DEFAULT_BOLD);
        btnSave.setBackground(roundBg("#15803D", 8));
        LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(40)
        );
        lpSave.topMargin = dp(10);
        btnSave.setLayoutParams(lpSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureTopInputs();
                Toast.makeText(MainPanelActivity.this, "Đã lưu cấu hình tọa độ!", Toast.LENGTH_SHORT).show();
            }
        });
        card.addView(btnSave);

        contentContainer.addView(card);
    }

    private EditText createCoordInput(int val) {
        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(val));
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        et.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        et.setLayoutParams(lp);
        return et;
    }

    private LinearLayout createCoordRow(String label, EditText etX, EditText etY) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#334155"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setLayoutParams(new LinearLayout.LayoutParams(dp(145), ViewGroup.LayoutParams.WRAP_CONTENT));
        r.addView(tv);
        r.addView(etX);
        r.addView(etY);
        return r;
    }

    private LinearLayout createWhiteCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundBg("#FFFFFF", 8));
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(8);
        card.setLayoutParams(lp);
        return card;
    }

    private TextView createColHeader(String text, String hex, int widthDp, float weight, int grav) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(hex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(grav);
        if (weight > 0f) {
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        } else {
            tv.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return tv;
    }

    private LinearLayout wrapCenter(View child, int widthDp) {
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(child);
        return box;
    }

    private void launchStealthFloatingHud() {
        captureTopInputs();

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Bước 1: Cấp quyền Hiển thị trên ứng dụng khác cho DolongDAO!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
            return;
        }

        TouchAssistService svc = TouchAssistService.getInstance();
        if (svc == null) {
            Toast.makeText(this, "Bước 2: Bật dịch vụ Trợ năng [DolongDAO Touch Panel]!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        svc.showFloatingHud();
        Toast.makeText(this, "Đã bật Thanh Nổi & Đóng hoàn toàn cửa sổ cài đặt!", Toast.LENGTH_SHORT).show();
        finishAndRemoveTask();
    }
}
