package com.realme.sys.touchpanel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainPanelActivity extends Activity {

    private AppConfig cfg;
    private int currentTabIdx = 0;

    private TextView tvHeaderSub;
    private Button btnModeShopee;
    private Button btnModeFood;

    private final Button[] tabButtons = new Button[5];
    private LinearLayout contentContainer;

    // Các ô nhập trong tab Cài Đặt ⚙️
    private EditText inpPriMinutes;
    private EditText inpMaxEscrowK;
    private EditText inpLoadMapDelayMs;
    private EditText inpSwipeDurationMs;
    private EditText inpAfterSwipeDelayMs;

    private EditText inpSwipeStartX, inpSwipeStartY;
    private EditText inpSwipeEndX, inpSwipeEndY;
    private EditText inpCoordReloadX, inpCoordReloadY;
    private EditText inpCoordExpandX, inpCoordExpandY;
    private EditText inpCoordBackX, inpCoordBackY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.parseColor("#EE4D2D"));

        cfg = AppConfig.load(this);
        buildMainLayout();
        switchTab(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        cfg = AppConfig.load(this);
        switchTab(currentTabIdx);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()
        );
    }

    private GradientDrawable roundBg(String hexColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(hexColor));
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }

    private int parseSafeInt(EditText et, int fallback) {
        if (et == null) return fallback;
        try {
            String s = et.getText().toString().trim();
            if (s.isEmpty()) return fallback;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return fallback;
        }
    }

    private void captureSettingsTabIfVisible() {
        if (inpPriMinutes != null) {
            cfg.priorityMinutes = Math.max(0, parseSafeInt(inpPriMinutes, cfg.priorityMinutes));
        }
        if (inpMaxEscrowK != null) {
            cfg.maxEscrowMinK = Math.max(0, parseSafeInt(inpMaxEscrowK, cfg.maxEscrowMinK));
        }
        if (inpLoadMapDelayMs != null) {
            cfg.loadMapDelayMs = Math.max(300, parseSafeInt(inpLoadMapDelayMs, cfg.loadMapDelayMs));
        }
        if (inpSwipeDurationMs != null) {
            cfg.swipeDurationMs = Math.max(40, parseSafeInt(inpSwipeDurationMs, cfg.swipeDurationMs));
        }
        if (inpAfterSwipeDelayMs != null) {
            cfg.afterSwipeDelayMs = Math.max(40, parseSafeInt(inpAfterSwipeDelayMs, cfg.afterSwipeDelayMs));
        }
        if (inpSwipeStartX != null) {
            cfg.swipeStartX = parseSafeInt(inpSwipeStartX, cfg.swipeStartX);
            cfg.swipeStartY = parseSafeInt(inpSwipeStartY, cfg.swipeStartY);
            cfg.swipeEndX = parseSafeInt(inpSwipeEndX, cfg.swipeEndX);
            cfg.swipeEndY = parseSafeInt(inpSwipeEndY, cfg.swipeEndY);
        }
        if (inpCoordReloadX != null) {
            cfg.reloadX = parseSafeInt(inpCoordReloadX, cfg.reloadX);
            cfg.reloadY = parseSafeInt(inpCoordReloadY, cfg.reloadY);
            cfg.expandX = parseSafeInt(inpCoordExpandX, cfg.expandX);
            cfg.expandY = parseSafeInt(inpCoordExpandY, cfg.expandY);
            cfg.backX = parseSafeInt(inpCoordBackX, cfg.backX);
            cfg.backY = parseSafeInt(inpCoordBackY, cfg.backY);
        }
        cfg.save(this);
    }

    private void clearSettingsInputRefs() {
        inpPriMinutes = null;
        inpMaxEscrowK = null;
        inpLoadMapDelayMs = null;
        inpSwipeDurationMs = null;
        inpAfterSwipeDelayMs = null;
        inpSwipeStartX = null;
        inpSwipeStartY = null;
        inpSwipeEndX = null;
        inpSwipeEndY = null;
        inpCoordReloadX = null;
        inpCoordReloadY = null;
        inpCoordExpandX = null;
        inpCoordExpandY = null;
        inpCoordBackX = null;
        inpCoordBackY = null;
    }

    private void buildMainLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F1F5F9"));

        // 1. Header Bar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(Color.parseColor("#EE4D2D"));
        header.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout headerTitleCol = new LinearLayout(this);
        headerTitleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lpTitleCol = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        headerTitleCol.setLayoutParams(lpTitleCol);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("DOLONGDAO - NATIVE v3.0");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        headerTitleCol.addView(tvTitle);

        tvHeaderSub = new TextView(this);
        tvHeaderSub.setText("Bấm [BẬT THANH NỔI] sẽ tự đóng sạch cửa sổ này");
        tvHeaderSub.setTextColor(Color.parseColor("#FFE4DE"));
        tvHeaderSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        headerTitleCol.addView(tvHeaderSub);
        header.addView(headerTitleCol);

        Button btnRunHud = new Button(this);
        btnRunHud.setText("BẬT THANH NỔI");
        btnRunHud.setAllCaps(false);
        btnRunHud.setTextColor(Color.parseColor("#EE4D2D"));
        btnRunHud.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnRunHud.setTypeface(Typeface.DEFAULT_BOLD);
        btnRunHud.setBackground(roundBg("#FFFFFF", 8));
        LinearLayout.LayoutParams lpBtnRun = new LinearLayout.LayoutParams(dp(120), dp(38));
        btnRunHud.setLayoutParams(lpBtnRun);
        btnRunHud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchStealthFloatingHud();
            }
        });
        header.addView(btnRunHud);
        root.addView(header);

        // 2. Top Mode Switcher Card
        LinearLayout topCard = new LinearLayout(this);
        topCard.setOrientation(LinearLayout.VERTICAL);
        topCard.setBackground(roundBg("#FFFFFF", 8));
        topCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lpTopCard = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpTopCard.setMargins(dp(10), dp(6), dp(10), dp(4));
        topCard.setLayoutParams(lpTopCard);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvModeLbl = new TextView(this);
        tvModeLbl.setText("CHẾ ĐỘ:");
        tvModeLbl.setTextColor(Color.parseColor("#1E293B"));
        tvModeLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tvModeLbl.setTypeface(Typeface.DEFAULT_BOLD);
        tvModeLbl.setPadding(0, 0, dp(6), 0);
        modeRow.addView(tvModeLbl);

        btnModeShopee = new Button(this);
        btnModeShopee.setText("🛍️ SHOPEE HỎA TỐC");
        btnModeShopee.setAllCaps(false);
        btnModeShopee.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnModeShopee.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lpM1 = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lpM1.rightMargin = dp(4);
        btnModeShopee.setLayoutParams(lpM1);

        btnModeFood = new Button(this);
        btnModeFood.setText("🍔 ĐƠN FOOD");
        btnModeFood.setAllCaps(false);
        btnModeFood.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnModeFood.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lpM2 = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lpM2.leftMargin = dp(4);
        btnModeFood.setLayoutParams(lpM2);

        btnModeShopee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureSettingsTabIfVisible();
                cfg.runMode = "SHOPEE";
                cfg.save(MainPanelActivity.this);
                updateModeButtonsStyle();
                switchTab(currentTabIdx);
            }
        });
        btnModeFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureSettingsTabIfVisible();
                cfg.runMode = "FOOD";
                cfg.save(MainPanelActivity.this);
                updateModeButtonsStyle();
                switchTab(currentTabIdx);
            }
        });

        modeRow.addView(btnModeShopee);
        modeRow.addView(btnModeFood);
        topCard.addView(modeRow);
        root.addView(topCard);

        // 3. Tab Bar (5 Tabs)
        LinearLayout tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(Color.WHITE);
        tabBar.setPadding(dp(4), dp(4), dp(4), dp(4));

        String[] tabTitles = new String[]{"Bộ Lọc", "Khu Vực", "Shop Khê", "Cài Đặt ⚙️", "Nhật Ký 📋"};
        for (int i = 0; i < 5; i++) {
            final int tabIdx = i;
            Button b = new Button(this);
            b.setText(tabTitles[i]);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setPadding(dp(1), dp(2), dp(1), dp(2));
            LinearLayout.LayoutParams lpTab = new LinearLayout.LayoutParams(0, dp(36), 1f);
            lpTab.setMargins(dp(1), 0, dp(1), 0);
            b.setLayoutParams(lpTab);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    captureSettingsTabIfVisible();
                    switchTab(tabIdx);
                }
            });
            tabButtons[i] = b;
            tabBar.addView(b);
        }
        root.addView(tabBar);

        // 4. Scrollable Content Area
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ));
        contentContainer = new LinearLayout(this);
        contentContainer.setOrientation(LinearLayout.VERTICAL);
        contentContainer.setPadding(dp(10), dp(8), dp(10), dp(28));
        sv.addView(contentContainer);
        root.addView(sv);

        updateModeButtonsStyle();
        setContentView(root);
    }

    private void updateModeButtonsStyle() {
        if ("FOOD".equals(cfg.runMode)) {
            btnModeFood.setBackground(roundBg("#EE4D2D", 6));
            btnModeFood.setTextColor(Color.WHITE);
            btnModeShopee.setBackground(roundBg("#E2E8F0", 6));
            btnModeShopee.setTextColor(Color.parseColor("#334155"));
        } else {
            btnModeShopee.setBackground(roundBg("#EE4D2D", 6));
            btnModeShopee.setTextColor(Color.WHITE);
            btnModeFood.setBackground(roundBg("#E2E8F0", 6));
            btnModeFood.setTextColor(Color.parseColor("#334155"));
        }
        tvHeaderSub.setText("Ưu tiên: " + cfg.priorityMinutes + "p | Quỹ: " + cfg.maxEscrowMinK
            + "K | LoadMap: " + cfg.loadMapDelayMs + "ms | Vuốt: " + cfg.swipeDurationMs
            + "ms | TrễVuốt: " + cfg.afterSwipeDelayMs + "ms");
    }

    private void switchTab(int idx) {
        currentTabIdx = idx;
        for (int i = 0; i < 5; i++) {
            if (i == idx) {
                tabButtons[i].setBackground(roundBg("#EE4D2D", 6));
                tabButtons[i].setTextColor(Color.WHITE);
            } else {
                tabButtons[i].setBackground(roundBg("#F1F5F9", 6));
                tabButtons[i].setTextColor(Color.parseColor("#64748B"));
            }
        }
        contentContainer.removeAllViews();
        clearSettingsInputRefs();
        updateModeButtonsStyle();

        if (idx == 0) {
            renderFilterTab();
        } else if (idx == 1) {
            renderGeographyTab();
        } else if (idx == 2) {
            renderBadShopsTab();
        } else if (idx == 3) {
            renderSettingsTab();
        } else {
            renderLogsTab();
        }
    }

    private void renderFilterTab() {
        if ("FOOD".equals(cfg.runMode)) {
            addDynamicRuleCard(
                "1. BỘ LỌC KILOMET (ĐƠN FOOD)",
                "Thêm/xóa tùy ý. Tích [Ưu tiên] chạy trong X phút đầu, sau đó mở rộng sang [Thường].",
                "km",
                cfg.foodKmRules
            );
        } else {
            addDynamicRuleCard(
                "1. BỘ LỌC KILOMET (KM)",
                "Từ X km trở lên (>=) hoặc trở xuống (<=). Không tích = Không giới hạn Km.",
                "km",
                cfg.shopeeKmRules
            );
            addBundleSectionCard();
            addDynamicRuleCard(
                "3. SỐ TIỀN GỐC (CƯỚC CƠ BẢN - ĐƠN VỊ: K)",
                "Tách biệt tuyệt đối với Tiền phụ. VD: 72.5k + 18k thì chỉ xét 72.5K.",
                "K",
                cfg.shopeeBasePayRules
            );
            addDynamicRuleCard(
                "4. SỐ TIỀN PHỤ (+THƯỞNG / CAO ĐIỂM - ĐƠN VỊ: K)",
                "Xét riêng số tiền đứng sau dấu '+'. Không tích = Không bắt buộc có tiền phụ.",
                "K",
                cfg.shopeeExtraPayRules
            );
        }
    }

    private void addDynamicRuleCard(String title, String sub, final String unit, final List<AppConfig.DynamicRule> rules) {
        LinearLayout card = createWhiteCard();

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvT = new TextView(this);
        tvT.setText(title);
        tvT.setTextColor(Color.parseColor("#1E293B"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        titleCol.addView(tvT);

        TextView tvS = new TextView(this);
        tvS.setText(sub);
        tvS.setTextColor(Color.parseColor("#64748B"));
        tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        titleCol.addView(tvS);
        topRow.addView(titleCol);

        Button btnAdd = new Button(this);
        btnAdd.setText("+ THÊM");
        btnAdd.setAllCaps(false);
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnAdd.setTypeface(Typeface.DEFAULT_BOLD);
        btnAdd.setBackground(roundBg("#0284C7", 6));
        btnAdd.setLayoutParams(new LinearLayout.LayoutParams(dp(74), dp(34)));
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptAddDynamicRule(unit, rules);
            }
        });
        topRow.addView(btnAdd);
        card.addView(topRow);

        LinearLayout tblHead = new LinearLayout(this);
        tblHead.setOrientation(LinearLayout.HORIZONTAL);
        tblHead.setBackgroundColor(Color.parseColor("#F8FAFC"));
        tblHead.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lpHead = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpHead.topMargin = dp(6);
        tblHead.setLayoutParams(lpHead);

        tblHead.addView(createColHeader("Điều kiện lọc", "#475569", 0, 1f, Gravity.START));
        tblHead.addView(createColHeader("Ưu tiên", "#EA580C", 64, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Thường", "#0284C7", 64, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Xóa", "#DC2626", 42, 0f, Gravity.CENTER));
        card.addView(tblHead);

        for (int i = 0; i < rules.size(); i++) {
            final int idx = i;
            final AppConfig.DynamicRule r = rules.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(2), dp(4), dp(2));

            TextView tvName = new TextView(this);
            tvName.setText(r.formatLabel(unit));
            tvName.setTextColor(Color.parseColor("#1E293B"));
            tvName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tvName);

            CheckBox cbPri = new CheckBox(this);
            cbPri.setChecked(r.pri);
            cbPri.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    r.pri = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbPri, 64));

            CheckBox cbNorm = new CheckBox(this);
            cbNorm.setChecked(r.norm);
            cbNorm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    r.norm = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbNorm, 64));

            Button btnDel = new Button(this);
            btnDel.setText("✕");
            btnDel.setTextColor(Color.parseColor("#DC2626"));
            btnDel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            btnDel.setBackgroundColor(Color.TRANSPARENT);
            btnDel.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(34)));
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    rules.remove(idx);
                    cfg.save(MainPanelActivity.this);
                    switchTab(currentTabIdx);
                }
            });
            row.addView(btnDel);
            card.addView(row);
        }

        contentContainer.addView(card);
    }

    private void promptAddDynamicRule(final String unit, final List<AppConfig.DynamicRule> targetRules) {
        final String[] options = new String[]{
            "Từ X " + unit + " trở lên ( >= X )",
            "Từ X " + unit + " trở xuống ( <= X )"
        };
        new AlertDialog.Builder(this)
            .setTitle("Chọn loại điều kiện " + unit + ":")
            .setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    final String opType = (which == 0) ? "ge" : "le";
                    String title = "ge".equals(opType)
                        ? ("Từ bao nhiêu " + unit + " trở lên?")
                        : ("Từ bao nhiêu " + unit + " trở xuống?");

                    final EditText input = new EditText(MainPanelActivity.this);
                    input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    input.setHint("Nhập con số...");

                    new AlertDialog.Builder(MainPanelActivity.this)
                        .setTitle(title)
                        .setView(input)
                        .setPositiveButton("THÊM", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                try {
                                    String raw = input.getText().toString().replace(",", ".").trim();
                                    double val = Double.parseDouble(raw);
                                    if (val < 0) return;
                                    targetRules.add(new AppConfig.DynamicRule(
                                        "rule_" + System.currentTimeMillis(), opType, val, false, false
                                    ));
                                    cfg.save(MainPanelActivity.this);
                                    switchTab(currentTabIdx);
                                } catch (Exception e) {
                                    Toast.makeText(MainPanelActivity.this, "Số không hợp lệ!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("HỦY", null)
                        .show();
                }
            })
            .show();
    }

    private void addBundleSectionCard() {
        LinearLayout card = createWhiteCard();

        TextView tvT = new TextView(this);
        tvT.setText("2. SỐ LƯỢNG ĐƠN (SOLO / CHÙM ĐƠN)");
        tvT.setTextColor(Color.parseColor("#1E293B"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(tvT);

        TextView tvS = new TextView(this);
        tvS.setText("Không tích ô nào = Nhận mọi số lượng đơn. Có tích = Chỉ nhận loại đã tích.");
        tvS.setTextColor(Color.parseColor("#64748B"));
        tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        card.addView(tvS);

        LinearLayout tblHead = new LinearLayout(this);
        tblHead.setOrientation(LinearLayout.HORIZONTAL);
        tblHead.setBackgroundColor(Color.parseColor("#F8FAFC"));
        tblHead.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lpHead = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpHead.topMargin = dp(6);
        tblHead.setLayoutParams(lpHead);

        tblHead.addView(createColHeader("Loại đơn / Chùm đơn", "#475569", 0, 1f, Gravity.START));
        tblHead.addView(createColHeader("Ưu tiên", "#EA580C", 72, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Thường", "#0284C7", 72, 0f, Gravity.CENTER));
        card.addView(tblHead);

        for (int i = 0; i < AppConfig.BUNDLE_KEYS.length; i++) {
            final String key = AppConfig.BUNDLE_KEYS[i];
            String label = AppConfig.BUNDLE_LABELS[i];
            AppConfig.TierState st = cfg.bundleRules.get(key);
            if (st == null) {
                st = new AppConfig.TierState(false, false);
                cfg.bundleRules.put(key, st);
            }
            final AppConfig.TierState finalSt = st;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(2), dp(4), dp(2));

            TextView tvL = new TextView(this);
            tvL.setText(label);
            tvL.setTextColor(Color.parseColor("#1E293B"));
            tvL.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvL.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tvL);

            CheckBox cbP = new CheckBox(this);
            cbP.setChecked(finalSt.pri);
            cbP.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.pri = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbP, 72));

            CheckBox cbN = new CheckBox(this);
            cbN.setChecked(finalSt.norm);
            cbN.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.norm = isChecked;
                    cfg.save(MainPanelActivity.this);
                }
            });
            row.addView(wrapCenter(cbN, 72));
            card.addView(row);
        }

        contentContainer.addView(card);
    }

    private void renderGeographyTab() {
        LinearLayout card = createWhiteCard();

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvT = new TextView(this);
        tvT.setText("PHÂN VÙNG ĐỊA LÝ HÀ NỘI (ĐIỂM GIAO CUỐI)");
        tvT.setTextColor(Color.parseColor("#1E293B"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        titleCol.addView(tvT);

        TextView tvS = new TextView(this);
        tvS.setText("12 Quận nội thành + 6 Huyện lân cận xếp trên; các Huyện xa xếp dưới.");
        tvS.setTextColor(Color.parseColor("#64748B"));
        tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        titleCol.addView(tvS);
        topRow.addView(titleCol);

        Button btnClear = new Button(this);
        btnClear.setText("Bỏ tích hết");
        btnClear.setAllCaps(false);
        btnClear.setTextColor(Color.parseColor("#DC2626"));
        btnClear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClear.setBackgroundColor(Color.TRANSPARENT);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cfg.prefAreas.clear();
                cfg.avoidAreas.clear();
                cfg.save(MainPanelActivity.this);
                switchTab(1);
            }
        });
        topRow.addView(btnClear);
        card.addView(topRow);

        LinearLayout tblHead = new LinearLayout(this);
        tblHead.setOrientation(LinearLayout.HORIZONTAL);
        tblHead.setBackgroundColor(Color.parseColor("#F8FAFC"));
        tblHead.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lpHead = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpHead.topMargin = dp(6);
        tblHead.setLayoutParams(lpHead);

        tblHead.addView(createColHeader("Quận / Huyện", "#475569", 0, 1f, Gravity.START));
        tblHead.addView(createColHeader("Ưu tiên", "#EA580C", 62, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("Thường", "#0284C7", 62, 0f, Gravity.CENTER));
        tblHead.addView(createColHeader("NÉ", "#DC2626", 62, 0f, Gravity.CENTER));
        card.addView(tblHead);

        addAreaGroupHeader(card, "★ 12 QUẬN NỘI THÀNH & 6 HUYỆN LÂN CẬN", "#EFF6FF", "#1D4ED8");
        addAreaRows(card, AppConfig.PRIORITY_HANOI_AREAS);

        addAreaGroupHeader(card, "• CÁC HUYỆN / THỊ XÃ XA XÔI", "#F1F5F9", "#475569");
        addAreaRows(card, AppConfig.OUTER_HANOI_AREAS);

        contentContainer.addView(card);
    }

    private void addAreaGroupHeader(LinearLayout parent, String text, String bgHex, String txtHex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setBackgroundColor(Color.parseColor(bgHex));
        tv.setTextColor(Color.parseColor(txtHex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(6), dp(4), dp(6), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = dp(4);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void addAreaRows(LinearLayout parent, String[] areas) {
        for (final String area : areas) {
            AppConfig.TierState st = cfg.prefAreas.get(area);
            if (st == null) {
                st = new AppConfig.TierState(false, false);
                cfg.prefAreas.put(area, st);
            }
            final AppConfig.TierState finalSt = st;
            boolean isAvoid = Boolean.TRUE.equals(cfg.avoidAreas.get(area));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(1), dp(4), dp(1));

            TextView tvA = new TextView(this);
            tvA.setText(area);
            tvA.setTextColor(Color.parseColor("#1E293B"));
            tvA.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvA.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(tvA);

            final CheckBox cbPri = new CheckBox(this);
            final CheckBox cbNorm = new CheckBox(this);
            final CheckBox cbAvoid = new CheckBox(this);

            cbPri.setChecked(finalSt.pri);
            cbNorm.setChecked(finalSt.norm);
            cbAvoid.setChecked(isAvoid);

            cbPri.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.pri = isChecked;
                    if (isChecked) {
                        cfg.avoidAreas.remove(area);
                        cbAvoid.setChecked(false);
                    }
                    cfg.save(MainPanelActivity.this);
                }
            });

            cbNorm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    finalSt.norm = isChecked;
                    if (isChecked) {
                        cfg.avoidAreas.remove(area);
                        cbAvoid.setChecked(false);
                    }
                    cfg.save(MainPanelActivity.this);
                }
            });

            cbAvoid.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        cfg.avoidAreas.put(area, true);
                        finalSt.pri = false;
                        finalSt.norm = false;
                        cbPri.setChecked(false);
                        cbNorm.setChecked(false);
                    } else {
                        cfg.avoidAreas.remove(area);
                    }
                    cfg.save(MainPanelActivity.this);
                }
            });

            row.addView(wrapCenter(cbPri, 62));
            row.addView(wrapCenter(cbNorm, 62));
            row.addView(wrapCenter(cbAvoid, 62));
            parent.addView(row);
        }
    }

    private void renderBadShopsTab() {
        LinearLayout addCard = createWhiteCard();

        TextView tvT = new TextView(this);
        tvT.setText("DANH SÁCH SHOP / QUÁN KHÊ (CHUẨN 100% KÝ TỰ)");
        tvT.setTextColor(Color.parseColor("#EE4D2D"));
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.DEFAULT_BOLD);
        addCard.addView(tvT);

        TextView tvSub = new TextView(this);
        tvSub.setText("• Khi đang bật thanh nổi, bấm nút [📌] để tự động trích xuất Tên + Địa chỉ Shop/Quán (nếu đang chạy tool sẽ tự tạm dừng để bảng Ghim đứng yên cho bạn bấm).\n• Hoặc nhập thủ công bên dưới:");
        tvSub.setTextColor(Color.parseColor("#475569"));
        tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvSub.setPadding(0, dp(4), 0, dp(6));
        addCard.addView(tvSub);

        final EditText inpName = new EditText(this);
        inpName.setHint("Tên Shop/Quán (hoặc để trống)");
        inpName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        addCard.addView(inpName);

        LinearLayout addrRow = new LinearLayout(this);
        addrRow.setOrientation(LinearLayout.HORIZONTAL);
        addrRow.setGravity(Gravity.CENTER_VERTICAL);

        final EditText inpAddr = new EditText(this);
        inpAddr.setHint("Chuỗi địa chỉ lấy hàng chính xác 100%...");
        inpAddr.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        inpAddr.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        addrRow.addView(inpAddr);

        Button btnAdd = new Button(this);
        btnAdd.setText("THÊM");
        btnAdd.setAllCaps(false);
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnAdd.setTypeface(Typeface.DEFAULT_BOLD);
        btnAdd.setBackground(roundBg("#EE4D2D", 6));
        LinearLayout.LayoutParams lpAdd = new LinearLayout.LayoutParams(dp(72), dp(38));
        lpAdd.leftMargin = dp(6);
        btnAdd.setLayoutParams(lpAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = inpName.getText().toString().trim();
                String a = inpAddr.getText().toString().trim();
                if (n.isEmpty() && a.isEmpty()) {
                    Toast.makeText(MainPanelActivity.this, "Hãy nhập Tên hoặc Địa chỉ Shop!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (cfg.addShopToBlacklist(MainPanelActivity.this, n, a)) {
                    inpName.setText("");
                    inpAddr.setText("");
                    switchTab(2);
                    Toast.makeText(MainPanelActivity.this, "Đã thêm vào Blacklist!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainPanelActivity.this, "Shop này đã có sẵn!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        addrRow.addView(btnAdd);
        addCard.addView(addrRow);
        contentContainer.addView(addCard);

        LinearLayout listCard = createWhiteCard();
        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvCount = new TextView(this);
        tvCount.setText("Đang lưu: " + cfg.badShops.size() + " Shop/Quán khê");
        tvCount.setTextColor(Color.parseColor("#1E293B"));
        tvCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvCount.setTypeface(Typeface.DEFAULT_BOLD);
        tvCount.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        headRow.addView(tvCount);

        Button btnClearAll = new Button(this);
        btnClearAll.setText("Xóa hết");
        btnClearAll.setAllCaps(false);
        btnClearAll.setTextColor(Color.parseColor("#DC2626"));
        btnClearAll.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClearAll.setBackgroundColor(Color.TRANSPARENT);
        btnClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cfg.badShops.clear();
                cfg.save(MainPanelActivity.this);
                switchTab(2);
            }
        });
        headRow.addView(btnClearAll);
        listCard.addView(headRow);

        for (int i = 0; i < cfg.badShops.size(); i++) {
            final int idx = i;
            AppConfig.BadShopItem item = cfg.badShops.get(i);

            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setBackgroundColor(Color.parseColor("#F8FAFC"));
            r.setPadding(dp(8), dp(6), dp(8), dp(6));
            LinearLayout.LayoutParams lpR = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lpR.topMargin = dp(4);
            r.setLayoutParams(lpR);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvSn = new TextView(this);
            tvSn.setText((i + 1) + ". " + ((item.name != null && !item.name.isEmpty()) ? item.name : "Shop Shopee (Ẩn tên ***)"));
            tvSn.setTextColor(Color.parseColor("#0F172A"));
            tvSn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvSn.setTypeface(Typeface.DEFAULT_BOLD);
            col.addView(tvSn);

            TextView tvSa = new TextView(this);
            tvSa.setText(item.addr);
            tvSa.setTextColor(Color.parseColor("#475569"));
            tvSa.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            col.addView(tvSa);
            r.addView(col);

            Button btnDel = new Button(this);
            btnDel.setText("Xóa");
            btnDel.setAllCaps(false);
            btnDel.setTextColor(Color.parseColor("#DC2626"));
            btnDel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            btnDel.setBackgroundColor(Color.TRANSPARENT);
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cfg.badShops.remove(idx);
                    cfg.save(MainPanelActivity.this);
                    switchTab(2);
                }
            });
            r.addView(btnDel);
            listCard.addView(r);
        }

        contentContainer.addView(listCard);
    }

    // Tab 4: Cài Đặt ⚙️
    private void renderSettingsTab() {
        LinearLayout timeCard = createWhiteCard();

        TextView tvTimeTitle = new TextView(this);
        tvTimeTitle.setText("⏱️ THÔNG SỐ THỜI GIAN & TIỀN QUỸ BƠM");
        tvTimeTitle.setTextColor(Color.parseColor("#EE4D2D"));
        tvTimeTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvTimeTitle.setTypeface(Typeface.DEFAULT_BOLD);
        timeCard.addView(tvTimeTitle);

        TextView tvTimeSub = new TextView(this);
        tvTimeSub.setText("Các thông số thời gian (ms) tự động biến thiên ngẫu nhiên ±100ms quanh con số bạn cài đặt.");
        tvTimeSub.setTextColor(Color.parseColor("#64748B"));
        tvTimeSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvTimeSub.setPadding(0, dp(2), 0, dp(6));
        timeCard.addView(tvTimeSub);

        inpPriMinutes = createSingleNumberInput(cfg.priorityMinutes, "#EE4D2D");
        timeCard.addView(createSingleSettingRow("Số phút chạy Ưu tiên (phút):", inpPriMinutes));

        inpMaxEscrowK = createSingleNumberInput(cfg.maxEscrowMinK, "#15803D");
        timeCard.addView(createSingleSettingRow("Tiền quỹ bơm tối đa (Đơn vị: K):", inpMaxEscrowK));

        inpLoadMapDelayMs = createSingleNumberInput(cfg.loadMapDelayMs, "#0284C7");
        timeCard.addView(createSingleSettingRow("Thời gian click Load Map (ms):", inpLoadMapDelayMs));

        inpSwipeDurationMs = createSingleNumberInput(cfg.swipeDurationMs, "#7C3AED");
        timeCard.addView(createSingleSettingRow("Thời gian vuốt đơn (ms):", inpSwipeDurationMs));

        inpAfterSwipeDelayMs = createSingleNumberInput(cfg.afterSwipeDelayMs, "#D97706");
        timeCard.addView(createSingleSettingRow("Thời gian trễ sau khi vuốt (ms):", inpAfterSwipeDelayMs));

        contentContainer.addView(timeCard);

        LinearLayout coordCard = createWhiteCard();

        TextView tvCoordTitle = new TextView(this);
        tvCoordTitle.setText("🎯 TỌA ĐỘ VUỐT ĐƠN (TĐ2 -> TĐ1) & CÁC NÚT BẤM");
        tvCoordTitle.setTextColor(Color.parseColor("#EE4D2D"));
        tvCoordTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvCoordTitle.setTypeface(Typeface.DEFAULT_BOLD);
        coordCard.addView(tvCoordTitle);

        TextView tvCoordSub = new TextView(this);
        tvCoordSub.setText("Mỗi lần click/vuốt sẽ tự động biến thiên nhẹ tọa độ và đi theo đường cong tự nhiên.");
        tvCoordSub.setTextColor(Color.parseColor("#64748B"));
        tvCoordSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvCoordSub.setPadding(0, dp(2), 0, dp(6));
        coordCard.addView(tvCoordSub);

        Button btnCross = new Button(this);
        btnCross.setText("🎯 BẬT 5 TÂM NGẮM KÉO THẢ TRỰC QUAN");
        btnCross.setAllCaps(false);
        btnCross.setTextColor(Color.WHITE);
        btnCross.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        btnCross.setTypeface(Typeface.DEFAULT_BOLD);
        btnCross.setBackground(roundBg("#2563EB", 8));
        LinearLayout.LayoutParams lpCross = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42)
        );
        lpCross.topMargin = dp(4);
        lpCross.bottomMargin = dp(8);
        btnCross.setLayoutParams(lpCross);
        btnCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureSettingsTabIfVisible();
                TouchAssistService svc = TouchAssistService.getInstance();
                if (svc == null) {
                    Toast.makeText(MainPanelActivity.this, "Hãy bật Trợ năng cho DolongDAO trước!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    return;
                }
                svc.showCrosshairTargets();
            }
        });
        coordCard.addView(btnCross);

        inpSwipeStartX = createCoordInput(cfg.swipeStartX);
        inpSwipeStartY = createCoordInput(cfg.swipeStartY);
        coordCard.addView(createCoordRow("👉 Tọa độ 2 - Đầu vuốt (X, Y):", inpSwipeStartX, inpSwipeStartY));

        inpSwipeEndX = createCoordInput(cfg.swipeEndX);
        inpSwipeEndY = createCoordInput(cfg.swipeEndY);
        coordCard.addView(createCoordRow("👈 Tọa độ 1 - Cuối vuốt (X, Y):", inpSwipeEndX, inpSwipeEndY));

        inpCoordReloadX = createCoordInput(cfg.reloadX);
        inpCoordReloadY = createCoordInput(cfg.reloadY);
        coordCard.addView(createCoordRow("🔄 Nút Load Map (X, Y):", inpCoordReloadX, inpCoordReloadY));

        inpCoordExpandX = createCoordInput(cfg.expandX);
        inpCoordExpandY = createCoordInput(cfg.expandY);
        coordCard.addView(createCoordRow("📂 Nút Mở rộng (X, Y):", inpCoordExpandX, inpCoordExpandY));

        inpCoordBackX = createCoordInput(cfg.backX);
        inpCoordBackY = createCoordInput(cfg.backY);
        coordCard.addView(createCoordRow("🔙 Nút Quay lại (X, Y):", inpCoordBackX, inpCoordBackY));

        Button btnSave = new Button(this);
        btnSave.setText("💾 LƯU TẤT CẢ CÀI ĐẶT");
        btnSave.setAllCaps(false);
        btnSave.setTextColor(Color.WHITE);
        btnSave.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        btnSave.setTypeface(Typeface.DEFAULT_BOLD);
        btnSave.setBackground(roundBg("#15803D", 8));
        LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42)
        );
        lpSave.topMargin = dp(10);
        btnSave.setLayoutParams(lpSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureSettingsTabIfVisible();
                updateModeButtonsStyle();
                RunLogger.log("💾 Đã lưu cài đặt: Ưu tiên=" + cfg.priorityMinutes + "p, Quỹ=" + cfg.maxEscrowMinK
                    + "K, LoadMap=" + cfg.loadMapDelayMs + "ms, Vuốt=" + cfg.swipeDurationMs
                    + "ms, TrễSauVuốt=" + cfg.afterSwipeDelayMs + "ms");
                Toast.makeText(MainPanelActivity.this, "Đã lưu toàn bộ thông số cài đặt!", Toast.LENGTH_SHORT).show();
            }
        });
        coordCard.addView(btnSave);

        contentContainer.addView(coordCard);
    }

    // Tab 5: Nhật Ký 📋
    private void renderLogsTab() {
        LinearLayout card = createWhiteCard();

        TextView tvTitle = new TextView(this);
        tvTitle.setText("📋 NHẬT KÝ HOẠT ĐỘNG (LƯU TRONG BỘ NHỚ & DOWNLOAD)");
        tvTitle.setTextColor(Color.parseColor("#0F172A"));
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText("Ghi lại chi tiết từng bước đọc đơn, lý do nhận/loại và tọa độ thực tế. Tự động lưu kèm tại Download/dolongdao_run_log.txt");
        tvSub.setTextColor(Color.parseColor("#64748B"));
        tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvSub.setPadding(0, dp(2), 0, dp(8));
        card.addView(tvSub);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER_VERTICAL);

        final TextView tvLogContent = new TextView(this);

        Button btnRefresh = new Button(this);
        btnRefresh.setText("🔄 Làm mới");
        btnRefresh.setAllCaps(false);
        btnRefresh.setTextColor(Color.WHITE);
        btnRefresh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnRefresh.setTypeface(Typeface.DEFAULT_BOLD);
        btnRefresh.setBackground(roundBg("#0284C7", 6));
        LinearLayout.LayoutParams lpRef = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lpRef.rightMargin = dp(4);
        btnRefresh.setLayoutParams(lpRef);
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvLogContent.setText(RunLogger.getAllLogsText());
                Toast.makeText(MainPanelActivity.this, "Đã cập nhật nhật ký mới nhất!", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnCopy = new Button(this);
        btnCopy.setText("📋 Sao chép Log");
        btnCopy.setAllCaps(false);
        btnCopy.setTextColor(Color.WHITE);
        btnCopy.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnCopy.setTypeface(Typeface.DEFAULT_BOLD);
        btnCopy.setBackground(roundBg("#16A34A", 6));
        LinearLayout.LayoutParams lpCopy = new LinearLayout.LayoutParams(0, dp(36), 1.2f);
        lpCopy.rightMargin = dp(4);
        btnCopy.setLayoutParams(lpCopy);
        btnCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt = RunLogger.getAllLogsText();
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("DolongDAO_Log", txt));
                    Toast.makeText(MainPanelActivity.this, "Đã sao chép toàn bộ Log vào bộ nhớ tạm!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button btnClear = new Button(this);
        btnClear.setText("🗑️ Xóa");
        btnClear.setAllCaps(false);
        btnClear.setTextColor(Color.WHITE);
        btnClear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnClear.setTypeface(Typeface.DEFAULT_BOLD);
        btnClear.setBackground(roundBg("#DC2626", 6));
        LinearLayout.LayoutParams lpClr = new LinearLayout.LayoutParams(0, dp(36), 0.8f);
        btnClear.setLayoutParams(lpClr);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RunLogger.clear();
                tvLogContent.setText(RunLogger.getAllLogsText());
                Toast.makeText(MainPanelActivity.this, "Đã xóa sạch nhật ký!", Toast.LENGTH_SHORT).show();
            }
        });

        btnRow.addView(btnRefresh);
        btnRow.addView(btnCopy);
        btnRow.addView(btnClear);
        card.addView(btnRow);

        tvLogContent.setText(RunLogger.getAllLogsText());
        tvLogContent.setTextColor(Color.parseColor("#E2E8F0"));
        tvLogContent.setBackground(roundBg("#0F172A", 8));
        tvLogContent.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvLogContent.setTypeface(Typeface.MONOSPACE);
        tvLogContent.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lpLog = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpLog.topMargin = dp(8);
        tvLogContent.setLayoutParams(lpLog);
        card.addView(tvLogContent);

        contentContainer.addView(card);
    }

    private EditText createSingleNumberInput(int val, String colorHex) {
        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(val));
        et.setTextColor(Color.parseColor(colorHex));
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        et.setTypeface(Typeface.DEFAULT_BOLD);
        et.setGravity(Gravity.CENTER);
        et.setLayoutParams(new LinearLayout.LayoutParams(dp(95), ViewGroup.LayoutParams.WRAP_CONTENT));
        return et;
    }

    private LinearLayout createSingleSettingRow(String label, EditText input) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(2), 0, dp(2));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#1E293B"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(tv);
        r.addView(input);
        return r;
    }

    private EditText createCoordInput(int val) {
        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(val));
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        et.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(68), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(4);
        et.setLayoutParams(lp);
        return et;
    }

    private LinearLayout createCoordRow(String label, EditText etX, EditText etY) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#334155"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(tv);
        r.addView(etX);
        r.addView(etY);
        return r;
    }

    private LinearLayout createWhiteCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundBg("#FFFFFF", 8));
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(8);
        card.setLayoutParams(lp);
        return card;
    }

    private TextView createColHeader(String text, String hex, int widthDp, float weight, int grav) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(hex));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(grav);
        if (weight > 0f) {
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        } else {
            tv.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return tv;
    }

    private LinearLayout wrapCenter(View child, int widthDp) {
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(child);
        return box;
    }

    private void launchStealthFloatingHud() {
        captureSettingsTabIfVisible();

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Bước 1: Cấp quyền Hiển thị trên ứng dụng khác cho DolongDAO!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
            return;
        }

        TouchAssistService svc = TouchAssistService.getInstance();
        if (svc == null) {
            Toast.makeText(this, "Bước 2: Bật dịch vụ Trợ năng [DolongDAO Touch Panel]!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        svc.showFloatingHud();
        Toast.makeText(this, "Đã bật Thanh Nổi & Đóng hoàn toàn cửa sổ cài đặt!", Toast.LENGTH_SHORT).show();
        finishAndRemoveTask();
    }
}
