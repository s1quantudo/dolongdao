package com.realme.sys.touchpanel;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TouchAssistService extends AccessibilityService {

    private static TouchAssistService instance;
    public static TouchAssistService getInstance() {
        return instance;
    }

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private WindowManager wm;

    private View hudView;
    private WindowManager.LayoutParams hudParams;
    private Button btnToggleRun;

    private View escrowView;
    private View pinModalView;
    private final List<View> crosshairViews = new ArrayList<>();

    private volatile boolean isScanning = false;
    private volatile boolean isWaitingEscrowTopup = false;
    private long sessionStartTimeMs = 0L;
    private String lastMapDotsSig = "";
    private String lastSwipedFp = "";
    private int pendingBundleOrderCount = 1;
    private String pendingOuterOrderFp = "";
    private boolean pendingOuterNeedsEscrow = false;
    private final Map<String, Boolean> rejectedFps = new HashMap<>();
    private Thread scannerThread;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Tuyệt đối tĩnh khi không quét - Không đọc node trong callback sự kiện để tránh lộ hành vi
    }

    @Override
    public void onInterrupt() {
        stopScanner();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdownAll(null);
        instance = null;
        return super.onUnbind(intent);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()
        );
    }

    private int randInt(int min, int max) {
        if (max <= min) return min;
        return min + random.nextInt(max - min + 1);
    }

    private GradientDrawable roundBg(String hexColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(hexColor));
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }

    private void toastSafe(final String msg) {
        if (msg == null || msg.isEmpty()) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void vibrateSafe(long ms) {
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(ms);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void playAlertTone(final boolean isVictory) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    vibrateSafe(isVictory ? 1200 : 700);
                    ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
                    int tone = isVictory ? ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD : ToneGenerator.TONE_PROP_BEEP2;
                    tg.startTone(tone, 800);
                    Thread.sleep(850);
                    if (isVictory) {
                        tg.startTone(tone, 800);
                        Thread.sleep(850);
                    }
                    tg.release();
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    public void performHumanClick(int baseX, int baseY, int radius) {
        try {
            int r = radius > 0 ? radius : 12;
            int x = Math.max(10, baseX + randInt(-r, r));
            int y = Math.max(10, baseY + randInt(-r, r));
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, randInt(48, 82));
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(stroke);
            dispatchGesture(b.build(), null, null);
        } catch (Exception ignored) {
        }
    }

    public void performFastSwipe(AppConfig cfg) {
        try {
            int sx = cfg.swipeStartX + randInt(-22, 22);
            int ex = cfg.swipeEndX + randInt(-22, 22);
            int sy = cfg.swipeY + randInt(-18, 18);
            int ey = sy + randInt(-12, 12);
            int dur = randInt(155, 205);
            Path p = new Path();
            p.moveTo(sx, sy);
            p.lineTo(ex, ey);
            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, dur);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(stroke);
            dispatchGesture(b.build(), null, null);
        } catch (Exception ignored) {
        }
    }

    private void tapReloadMap(AppConfig cfg) {
        performHumanClick(cfg.reloadX, cfg.reloadY, 14);
    }

    private void tapExpandDetail(AppConfig cfg) {
        performHumanClick(cfg.expandX, cfg.expandY, 12);
    }

    private void tapBackFromDetail(AppConfig cfg) {
        performHumanClick(cfg.backX, cfg.backY, 12);
    }

    public void showFloatingHud() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!Settings.canDrawOverlays(TouchAssistService.this)) {
                    toastSafe("Vui lòng cấp quyền Hiển thị trên ứng dụng khác!");
                    return;
                }
                closeCrosshairTargets();
                if (hudView != null) {
                    return;
                }

                LinearLayout root = new LinearLayout(TouchAssistService.this);
                root.setOrientation(LinearLayout.HORIZONTAL);
                root.setGravity(Gravity.CENTER_VERTICAL);
                root.setPadding(dp(8), dp(5), dp(8), dp(5));
                root.setBackground(roundBg("#EE1E293B", 14));

                TextView tvDrag = new TextView(TouchAssistService.this);
                tvDrag.setText("✥");
                tvDrag.setTextColor(Color.parseColor("#94A3B8"));
                tvDrag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                tvDrag.setPadding(dp(6), dp(2), dp(8), dp(2));
                root.addView(tvDrag);

                btnToggleRun = createHudButton("CHẠY", "#10B981", 64);
                LinearLayout.LayoutParams lpRun = (LinearLayout.LayoutParams) btnToggleRun.getLayoutParams();
                lpRun.rightMargin = dp(4);
                root.addView(btnToggleRun);

                Button btnPin = createHudButton("📌", "#F59E0B", 38);
                LinearLayout.LayoutParams lpPin = (LinearLayout.LayoutParams) btnPin.getLayoutParams();
                lpPin.rightMargin = dp(4);
                root.addView(btnPin);

                Button btnCfg = createHudButton("⚙️", "#0284C7", 38);
                LinearLayout.LayoutParams lpCfg = (LinearLayout.LayoutParams) btnCfg.getLayoutParams();
                lpCfg.rightMargin = dp(4);
                root.addView(btnCfg);

                Button btnClose = createHudButton("X", "#EF4444", 36);
                root.addView(btnClose);

                hudParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                hudParams.gravity = Gravity.TOP | Gravity.START;
                hudParams.x = 30;
                hudParams.y = 140;

                tvDrag.setOnTouchListener(new View.OnTouchListener() {
                    private float downX, downY;
                    private int origX, origY;

                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                downX = event.getRawX();
                                downY = event.getRawY();
                                origX = hudParams.x;
                                origY = hudParams.y;
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                hudParams.x = origX + (int) (event.getRawX() - downX);
                                hudParams.y = origY + (int) (event.getRawY() - downY);
                                try {
                                    wm.updateViewLayout(hudView, hudParams);
                                } catch (Exception ignored) {
                                }
                                return true;
                        }
                        return true;
                    }
                });

                btnToggleRun.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!isScanning) {
                            sessionStartTimeMs = System.currentTimeMillis();
                            btnToggleRun.setText("DỪNG");
                            btnToggleRun.setBackground(roundBg("#EA580C", 8));
                            toastSafe("▶️ Bắt đầu lọc đơn!");
                            startScanner();
                        } else {
                            stopScanner();
                            btnToggleRun.setText("CHẠY");
                            btnToggleRun.setBackground(roundBg("#10B981", 8));
                            toastSafe("⏸ Đã dừng quét hoàn toàn (Tĩnh 100%).");
                        }
                    }
                });

                btnPin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        handlePinBadShopClick();
                    }
                });

                btnCfg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        stopScanner();
                        removeHudView();
                        Intent it = new Intent(TouchAssistService.this, MainPanelActivity.class);
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(it);
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        shutdownAll("Đã tắt Thanh Nổi.");
                    }
                });

                hudView = root;
                try {
                    wm.addView(hudView, hudParams);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private Button createHudButton(String text, String bgHex, int widthDp) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setAllCaps(false);
        b.setBackground(roundBg(bgHex, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(34));
        b.setLayoutParams(lp);
        return b;
    }

    private void removeHudView() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (hudView != null) {
                    try {
                        wm.removeView(hudView);
                    } catch (Exception ignored) {
                    }
                    hudView = null;
                }
            }
        });
    }

    private void closeEscrowModal() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (escrowView != null) {
                    try {
                        wm.removeView(escrowView);
                    } catch (Exception ignored) {
                    }
                    escrowView = null;
                }
            }
        });
    }

    private void closePinModal() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (pinModalView != null) {
                    try {
                        wm.removeView(pinModalView);
                    } catch (Exception ignored) {
                    }
                    pinModalView = null;
                }
            }
        });
    }

    public void shutdownAll(String msg) {
        stopScanner();
        closeEscrowModal();
        closePinModal();
        closeCrosshairTargets();
        removeHudView();
        if (msg != null && !msg.isEmpty()) {
            toastSafe(msg);
        }
    }

    private void showEscrowTopupFloatingButton(final int minRequiredVnd, final String orderFp) {
        if (escrowView != null) return;
        isWaitingEscrowTopup = true;
        playAlertTone(false);

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (escrowView != null) return;
                LinearLayout card = new LinearLayout(TouchAssistService.this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                card.setBackground(roundBg("#FFFBEB", 14));

                LinearLayout topRow = new LinearLayout(TouchAssistService.this);
                topRow.setOrientation(LinearLayout.HORIZONTAL);
                topRow.setGravity(Gravity.CENTER_VERTICAL);

                TextView tvDrag = new TextView(TouchAssistService.this);
                tvDrag.setText("✥ ");
                tvDrag.setTextColor(Color.parseColor("#B45309"));
                tvDrag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                topRow.addView(tvDrag);

                int reqK = (int) Math.ceil(minRequiredVnd / 1000.0);
                TextView tvInfo = new TextView(TouchAssistService.this);
                tvInfo.setText("⚠️ Quỹ tối thiểu: " + reqK + "k (Kéo ✥)");
                tvInfo.setTextColor(Color.parseColor("#DC2626"));
                tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                tvInfo.setTypeface(Typeface.DEFAULT_BOLD);
                topRow.addView(tvInfo);
                card.addView(topRow);

                LinearLayout btnRow = new LinearLayout(TouchAssistService.this);
                btnRow.setOrientation(LinearLayout.HORIZONTAL);
                btnRow.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                );
                lpRow.topMargin = dp(8);
                btnRow.setLayoutParams(lpRow);

                Button btnSkip = createHudButton("BỎ QUA", "#64748B", 82);
                LinearLayout.LayoutParams lpSkip = (LinearLayout.LayoutParams) btnSkip.getLayoutParams();
                lpSkip.rightMargin = dp(8);

                Button btnDone = createHudButton("ĐÃ NẠP", "#16A34A", 88);
                btnRow.addView(btnSkip);
                btnRow.addView(btnDone);
                card.addView(btnRow);

                final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lp.gravity = Gravity.TOP | Gravity.START;
                lp.x = 60;
                lp.y = 280;

                tvDrag.setOnTouchListener(new View.OnTouchListener() {
                    private float dx, dy;
                    private int wx, wy;
                    @Override
                    public boolean onTouch(View v, MotionEvent ev) {
                        switch (ev.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                dx = ev.getRawX();
                                dy = ev.getRawY();
                                wx = lp.x;
                                wy = lp.y;
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                lp.x = wx + (int) (ev.getRawX() - dx);
                                lp.y = wy + (int) (ev.getRawY() - dy);
                                try {
                                    wm.updateViewLayout(escrowView, lp);
                                } catch (Exception ignored) {
                                }
                                return true;
                        }
                        return true;
                    }
                });

                btnSkip.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (orderFp != null && !orderFp.isEmpty()) {
                            rejectedFps.put(orderFp, true);
                        }
                        closeEscrowModal();
                        isWaitingEscrowTopup = false;
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                ScreenParser.ParsedScreen cur = ScreenParser.parseShopeeScreen(
                                    ScreenParser.readCurrentScreenItems(TouchAssistService.this)
                                );
                                if (cur != null && "ESCROW_DIALOG".equals(cur.screenType) && cur.dialogCancelBtnPoint != null) {
                                    performHumanClick(cur.dialogCancelBtnPoint.x, cur.dialogCancelBtnPoint.y, 10);
                                }
                            }
                        }).start();
                    }
                });

                btnDone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (orderFp != null && !orderFp.isEmpty()) {
                            AppConfig cfg = AppConfig.load(TouchAssistService.this);
                            cfg.savedWhitelistedFp = orderFp;
                            cfg.savedWhitelistedTime = System.currentTimeMillis();
                            cfg.save(TouchAssistService.this);
                        }
                        closeEscrowModal();
                        isWaitingEscrowTopup = false;
                        toastSafe("Đã nhớ đơn Ký Quỹ! Gặp lại sẽ tự động bấm Nhận.");
                    }
                });

                escrowView = card;
                try {
                    wm.addView(escrowView, lp);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void handlePinBadShopClick() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final ScreenParser.ParsedScreen parsed = ScreenParser.parseShopeeScreen(
                    ScreenParser.readCurrentScreenItems(TouchAssistService.this)
                );
                if (parsed == null) {
                    toastSafe("Không đọc được màn hình Shopee!");
                    return;
                }
                if ("DETAIL_SCREEN".equals(parsed.screenType) && !parsed.detailPickupList.isEmpty()) {
                    showPinDetailListOverlay(parsed.detailPickupList);
                    return;
                }
                if ("OUTER_CARD".equals(parsed.screenType) && parsed.pickupAddressText != null && !parsed.pickupAddressText.isEmpty()) {
                    showPinConfirmOverlay(parsed.pickupLabelText, parsed.pickupAddressText);
                    return;
                }
                toastSafe("Hãy mở màn hình có đơn Shopee rồi bấm [📌]!");
            }
        }).start();
    }

    private void showPinDetailListOverlay(final List<String> pickupList) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                closePinModal();
                LinearLayout box = new LinearLayout(TouchAssistService.this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(14), dp(12), dp(14), dp(12));
                box.setBackground(roundBg("#FFFFFF", 14));

                TextView tvTitle = new TextView(TouchAssistService.this);
                tvTitle.setText("📌 Chọn đúng Điểm lấy (Shop khê) trong chùm đơn:");
                tvTitle.setTextColor(Color.parseColor("#0F172A"));
                tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
                box.addView(tvTitle);

                ScrollView sv = new ScrollView(TouchAssistService.this);
                LinearLayout listHost = new LinearLayout(TouchAssistService.this);
                listHost.setOrientation(LinearLayout.VERTICAL);
                listHost.setPadding(0, dp(8), 0, dp(8));

                for (int i = 0; i < pickupList.size(); i++) {
                    final String addr = pickupList.get(i);
                    Button itemBtn = new Button(TouchAssistService.this);
                    itemBtn.setText((i + 1) + ". " + addr);
                    itemBtn.setAllCaps(false);
                    itemBtn.setTextColor(Color.parseColor("#1E293B"));
                    itemBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                    itemBtn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                    itemBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
                    itemBtn.setBackground(roundBg("#F1F5F9", 8));
                    LinearLayout.LayoutParams lpItem = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                    );
                    lpItem.bottomMargin = dp(6);
                    itemBtn.setLayoutParams(lpItem);

                    itemBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            closePinModal();
                            showPinConfirmOverlay("", addr);
                        }
                    });
                    listHost.addView(itemBtn);
                }
                sv.addView(listHost);
                LinearLayout.LayoutParams lpSv = new LinearLayout.LayoutParams(
                    dp(310), LinearLayout.LayoutParams.WRAP_CONTENT
                );
                box.addView(sv, lpSv);

                Button btnCancel = createHudButton("ĐÓNG", "#64748B", 90);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        closePinModal();
                    }
                });
                box.addView(btnCancel);

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lp.gravity = Gravity.CENTER;
                pinModalView = box;
                try {
                    wm.addView(pinModalView, lp);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void showPinConfirmOverlay(final String sName, final String sAddr) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                closePinModal();
                LinearLayout box = new LinearLayout(TouchAssistService.this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(16), dp(14), dp(16), dp(14));
                box.setBackground(roundBg("#FFFFFF", 14));

                TextView tvTitle = new TextView(TouchAssistService.this);
                tvTitle.setText("📌 Xác nhận Ghim Shop/Quán Khê");
                tvTitle.setTextColor(Color.parseColor("#EE4D2D"));
                tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
                box.addView(tvTitle);

                TextView tvBody = new TextView(TouchAssistService.this);
                String detail = ((sName != null && !sName.isEmpty()) ? (sName + "\n") : "") + sAddr;
                tvBody.setText(detail);
                tvBody.setTextColor(Color.parseColor("#334155"));
                tvBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                tvBody.setPadding(0, dp(8), 0, dp(12));
                LinearLayout.LayoutParams lpBody = new LinearLayout.LayoutParams(dp(290), LinearLayout.LayoutParams.WRAP_CONTENT);
                box.addView(tvBody, lpBody);

                LinearLayout row = new LinearLayout(TouchAssistService.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.END);

                Button btnNo = createHudButton("HỦY", "#64748B", 80);
                LinearLayout.LayoutParams lpNo = (LinearLayout.LayoutParams) btnNo.getLayoutParams();
                lpNo.rightMargin = dp(8);

                Button btnYes = createHudButton("GHIM NGAY", "#EE4D2D", 105);

                btnNo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        closePinModal();
                    }
                });

                btnYes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AppConfig cfg = AppConfig.load(TouchAssistService.this);
                        if (cfg.addShopToBlacklist(TouchAssistService.this, sName, sAddr)) {
                            vibrateSafe(150);
                            toastSafe("📌 Đã lưu vào danh sách Shop/Quán Khê!");
                        } else {
                            toastSafe("Shop/Quán này đã có trong Blacklist!");
                        }
                        closePinModal();
                    }
                });

                row.addView(btnNo);
                row.addView(btnYes);
                box.addView(row);

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lp.gravity = Gravity.CENTER;
                pinModalView = box;
                try {
                    wm.addView(pinModalView, lp);
                } catch (Exception ignored) {
                }
            }
        });
    }

    public void closeCrosshairTargets() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                for (View v : crosshairViews) {
                    try {
                        wm.removeView(v);
                    } catch (Exception ignored) {
                    }
                }
                crosshairViews.clear();
            }
        });
    }

    public void showCrosshairTargets() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!Settings.canDrawOverlays(TouchAssistService.this)) {
                    toastSafe("Hãy cấp quyền Vẽ trên ứng dụng khác trước!");
                    return;
                }
                closeCrosshairTargets();
                final AppConfig cfg = AppConfig.load(TouchAssistService.this);
                final int[] coords = new int[]{
                    cfg.reloadX, cfg.reloadY,
                    cfg.expandX, cfg.expandY,
                    cfg.backX, cfg.backY
                };

                addSingleCrosshair("🔄 Load Map", "#0284C7", coords[0], coords[1], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) {
                        coords[0] = cx;
                        coords[1] = cy;
                    }
                });
                addSingleCrosshair("Mở rộng", "#EA580C", coords[2], coords[3], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) {
                        coords[2] = cx;
                        coords[3] = cy;
                    }
                });
                addSingleCrosshair("Quay lại", "#7C3AED", coords[4], coords[5], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) {
                        coords[4] = cx;
                        coords[5] = cy;
                    }
                });

                LinearLayout bar = new LinearLayout(TouchAssistService.this);
                bar.setOrientation(LinearLayout.HORIZONTAL);
                bar.setPadding(dp(10), dp(6), dp(10), dp(6));
                bar.setBackground(roundBg("#1E293B", 12));

                Button btnSave = createHudButton("LƯU TỌA ĐỘ", "#10B981", 100);
                LinearLayout.LayoutParams lpS = (LinearLayout.LayoutParams) btnSave.getLayoutParams();
                lpS.rightMargin = dp(6);

                Button btnCancel = createHudButton("HỦY", "#EF4444", 54);
                bar.addView(btnSave);
                bar.addView(btnCancel);

                WindowManager.LayoutParams lpBar = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lpBar.gravity = Gravity.TOP | Gravity.START;
                lpBar.x = 40;
                lpBar.y = 140;

                btnSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AppConfig c = AppConfig.load(TouchAssistService.this);
                        c.reloadX = coords[0];
                        c.reloadY = coords[1];
                        c.expandX = coords[2];
                        c.expandY = coords[3];
                        c.backX = coords[4];
                        c.backY = coords[5];
                        c.save(TouchAssistService.this);
                        closeCrosshairTargets();
                        toastSafe("Đã lưu tọa độ mới!");
                    }
                });
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        closeCrosshairTargets();
                    }
                });

                crosshairViews.add(bar);
                try {
                    wm.addView(bar, lpBar);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private interface CoordCallback {
        void onMove(int cx, int cy);
    }

    private void addSingleCrosshair(String label, String hex, int initX, int initY, final CoordCallback cb) {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.parseColor("#44000000"));
        box.setPadding(dp(2), dp(2), dp(2), dp(2));

        TextView tvTag = new TextView(this);
        tvTag.setText(label);
        tvTag.setTextColor(Color.WHITE);
        tvTag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tvTag.setTypeface(Typeface.DEFAULT_BOLD);
        tvTag.setBackgroundColor(Color.parseColor(hex));
        tvTag.setPadding(dp(4), dp(1), dp(4), dp(1));
        box.addView(tvTag);

        TextView tvCross = new TextView(this);
        tvCross.setText("🎯");
        tvCross.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        box.addView(tvCross);

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = initX - 40;
        lp.y = initY - 40;

        tvCross.setOnTouchListener(new View.OnTouchListener() {
            private float dx, dy;
            private int wx, wy;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = event.getRawX();
                        dy = event.getRawY();
                        wx = lp.x;
                        wy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int nx = wx + (int) (event.getRawX() - dx);
                        int ny = wy + (int) (event.getRawY() - dy);
                        lp.x = nx;
                        lp.y = ny;
                        try {
                            wm.updateViewLayout(box, lp);
                        } catch (Exception ignored) {
                        }
                        cb.onMove(nx + 40, ny + 40);
                        return true;
                }
                return true;
            }
        });

        crosshairViews.add(box);
        try {
            wm.addView(box, lp);
        } catch (Exception ignored) {
        }
    }

    private boolean isWhitelistedOrderMatch(String fp, AppConfig cfg) {
        if (fp == null || fp.isEmpty() || cfg.savedWhitelistedFp == null || !fp.equals(cfg.savedWhitelistedFp)) {
            return false;
        }
        if (System.currentTimeMillis() - cfg.savedWhitelistedTime > 20L * 60L * 1000L) {
            cfg.savedWhitelistedFp = "";
            cfg.save(this);
            return false;
        }
        return true;
    }

    private ScreenParser.ParsedScreen waitForCardChangeAfterSwipe(String oldFp, long maxWaitMs) {
        long startWait = System.currentTimeMillis();
        try {
            Thread.sleep(135);
        } catch (InterruptedException e) {
            return null;
        }
        while (System.currentTimeMillis() - startWait < maxWaitMs) {
            ScreenParser.ParsedScreen sc = ScreenParser.parseShopeeScreen(readNodesNow());
            if (sc == null) {
                try { Thread.sleep(55); } catch (InterruptedException e) { return null; }
                continue;
            }
            if ("END_OF_CARDS".equals(sc.screenType) || "EMPTY_MAP".equals(sc.screenType)) {
                return sc;
            }
            if ("OUTER_CARD".equals(sc.screenType) && sc.fingerprint != null && !sc.fingerprint.isEmpty()
                    && !sc.fingerprint.equals(oldFp) && sc.dropoffAddressText != null && !sc.dropoffAddressText.isEmpty()) {
                return sc;
            }
            try { Thread.sleep(55); } catch (InterruptedException e) { return null; }
        }
        return ScreenParser.parseShopeeScreen(readNodesNow());
    }

    private List<ScreenParser.NodeItem> readNodesNow() {
        return ScreenParser.readCurrentScreenItems(this);
    }

    private void stopScanner() {
        isScanning = false;
        if (scannerThread != null) {
            try {
                scannerThread.interrupt();
            } catch (Exception ignored) {
            }
            scannerThread = null;
        }
    }

    private void startScanner() {
        stopScanner();
        final AppConfig cfg = AppConfig.load(this);
        isScanning = true;
        if (sessionStartTimeMs == 0L) {
            sessionStartTimeMs = System.currentTimeMillis();
        }

        scannerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    tapReloadMap(cfg);
                    Thread.sleep(350);
                } catch (InterruptedException e) {
                    return;
                }

                ScreenParser.ParsedScreen cachedScreen = null;
                while (isScanning && !Thread.currentThread().isInterrupted()) {
                    try {
                        if (isWaitingEscrowTopup) {
                            Thread.sleep(400);
                            continue;
                        }

                        long elapsedMs = System.currentTimeMillis() - sessionStartTimeMs;
                        boolean useNormalToo = (elapsedMs >= (long) cfg.priorityMinutes * 60L * 1000L);

                        ScreenParser.ParsedScreen screen = (cachedScreen != null)
                            ? cachedScreen
                            : ScreenParser.parseShopeeScreen(readNodesNow());
                        cachedScreen = null;

                        if (screen == null || "UNKNOWN".equals(screen.screenType)) {
                            Thread.sleep(randInt(250, 350));
                            continue;
                        }

                        if ("EMPTY_MAP".equals(screen.screenType)) {
                            tapReloadMap(cfg);
                            Thread.sleep(randInt(380, 480));
                            continue;
                        }

                        if ("END_OF_CARDS".equals(screen.screenType)) {
                            lastMapDotsSig = screen.mapDotsSignature;
                            if (screen.reloadPageBtnPoint != null) {
                                performHumanClick(screen.reloadPageBtnPoint.x, screen.reloadPageBtnPoint.y, 14);
                            } else {
                                tapReloadMap(cfg);
                            }
                            Thread.sleep(randInt(380, 480));

                            ScreenParser.ParsedScreen afterLoad = ScreenParser.parseShopeeScreen(readNodesNow());
                            if (afterLoad != null && "OUTER_CARD".equals(afterLoad.screenType)) {
                                if (lastMapDotsSig != null && !lastMapDotsSig.isEmpty()
                                        && lastMapDotsSig.equals(afterLoad.mapDotsSignature)) {
                                    tapReloadMap(cfg);
                                    Thread.sleep(randInt(380, 480));
                                    continue;
                                }
                                lastMapDotsSig = afterLoad.mapDotsSignature;
                                cachedScreen = afterLoad;
                            }
                            continue;
                        }

                        if ("ESCROW_DIALOG".equals(screen.screenType)) {
                            int reqVnd = screen.escrowMinRequiredVnd != null ? screen.escrowMinRequiredVnd : 0;
                            int maxAllowedVnd = cfg.maxEscrowMinK * 1000;
                            if (reqVnd > 0 && reqVnd <= maxAllowedVnd) {
                                showEscrowTopupFloatingButton(reqVnd, pendingOuterOrderFp);
                            } else {
                                if (pendingOuterOrderFp != null && !pendingOuterOrderFp.isEmpty()) {
                                    rejectedFps.put(pendingOuterOrderFp, true);
                                }
                                if (screen.dialogCancelBtnPoint != null) {
                                    performHumanClick(screen.dialogCancelBtnPoint.x, screen.dialogCancelBtnPoint.y, 10);
                                } else {
                                    performHumanClick(315, 1369, 10);
                                }
                                Thread.sleep(randInt(340, 440));
                            }
                            continue;
                        }

                        if ("DETAIL_SCREEN".equals(screen.screenType)) {
                            int nPickups = Math.min(Math.max(pendingBundleOrderCount, 2), screen.detailPickupList.size());
                            boolean hitBadShop = false;
                            for (int pIdx = 0; pIdx < nPickups; pIdx++) {
                                if (ScreenParser.isBadShopMatch("", screen.detailPickupList.get(pIdx), cfg)) {
                                    hitBadShop = true;
                                    break;
                                }
                            }
                            boolean detailGeoOk = true;
                            if ("SHOPEE".equals(cfg.runMode) && screen.dropoffAddressText != null && !screen.dropoffAddressText.isEmpty()) {
                                detailGeoOk = ScreenParser.checkFinalDropoffArea(screen.dropoffAddressText, cfg, useNormalToo);
                            }
                            if (hitBadShop || !detailGeoOk) {
                                if (pendingOuterOrderFp != null && !pendingOuterOrderFp.isEmpty()) {
                                    rejectedFps.put(pendingOuterOrderFp, true);
                                }
                                tapBackFromDetail(cfg);
                                Thread.sleep(randInt(340, 430));
                                continue;
                            }
                            if (screen.acceptBtnPoint != null) {
                                performHumanClick(screen.acceptBtnPoint.x, screen.acceptBtnPoint.y, 14);
                                Thread.sleep(340);
                                if (!pendingOuterNeedsEscrow) {
                                    playAlertTone(true);
                                    shutdownAll("🎯 ĐÃ NHẬN CHÙM ĐƠN THÀNH CÔNG!");
                                    break;
                                }
                            }
                            continue;
                        }

                        if ("OUTER_CARD".equals(screen.screenType)) {
                            String fp = screen.fingerprint;
                            if (isWhitelistedOrderMatch(fp, cfg) && screen.acceptBtnPoint != null) {
                                performHumanClick(screen.acceptBtnPoint.x, screen.acceptBtnPoint.y, 14);
                                cfg.savedWhitelistedFp = "";
                                cfg.save(TouchAssistService.this);
                                Thread.sleep(340);
                                playAlertTone(true);
                                shutdownAll("🎯 ĐÃ NHẬN ĐƠN KÝ QUỸ THÀNH CÔNG!");
                                break;
                            }
                            if (fp != null && Boolean.TRUE.equals(rejectedFps.get(fp))) {
                                if (fp.equals(lastSwipedFp)) {
                                    lastSwipedFp = "";
                                    lastMapDotsSig = screen.mapDotsSignature;
                                    tapReloadMap(cfg);
                                    Thread.sleep(randInt(380, 480));
                                    continue;
                                }
                                lastSwipedFp = fp;
                                performFastSwipe(cfg);
                                cachedScreen = waitForCardChangeAfterSwipe(fp, 320);
                                continue;
                            }

                            boolean pass = ScreenParser.evaluateOuterOrderCard(screen, cfg, useNormalToo);
                            if (!pass) {
                                if (fp != null && !fp.isEmpty()) {
                                    rejectedFps.put(fp, true);
                                }
                                lastSwipedFp = fp;
                                performFastSwipe(cfg);
                                cachedScreen = waitForCardChangeAfterSwipe(fp, 320);
                                continue;
                            }

                            pendingOuterOrderFp = fp;
                            pendingOuterNeedsEscrow = screen.needsEscrow;
                            pendingBundleOrderCount = screen.orderCount;

                            if (screen.orderCount >= 2) {
                                tapExpandDetail(cfg);
                                Thread.sleep(randInt(320, 400));
                                continue;
                            }
                            if (screen.needsEscrow) {
                                if (screen.escrowBarPoint != null) {
                                    performHumanClick(screen.escrowBarPoint.x, screen.escrowBarPoint.y, 14);
                                } else {
                                    performHumanClick(540, 2275, 14);
                                }
                                Thread.sleep(randInt(340, 420));
                                continue;
                            } else if (screen.acceptBtnPoint != null) {
                                performHumanClick(screen.acceptBtnPoint.x, screen.acceptBtnPoint.y, 14);
                                Thread.sleep(340);
                                playAlertTone(true);
                                shutdownAll("🎯 ĐÃ NHẬN ĐƠN THÀNH CÔNG!");
                                break;
                            }
                        }

                        Thread.sleep(randInt(220, 320));
                    } catch (InterruptedException ie) {
                        break;
                    } catch (Exception ignored) {
                        try { Thread.sleep(300); } catch (InterruptedException ie) { break; }
                    }
                }
            }
        });
        scannerThread.start();
    }
}
