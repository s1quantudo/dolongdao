package com.realme.sys.touchpanel;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TouchAssistService extends AccessibilityService {

    private static TouchAssistService instance;
    public static TouchAssistService getInstance() {
        return instance;
    }

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private WindowManager wm;

    private View hudView;
    private WindowManager.LayoutParams hudParams;
    private Button btnToggleRun;

    private View escrowView;
    private View pinModalView;
    private final List<View> crosshairViews = new ArrayList<>();

    private volatile boolean isScanning = false;
    private volatile boolean isWaitingEscrowTopup = false;
    private long sessionStartTimeMs = 0L;
    private String lastMapDotsSig = "";
    private String lastSwipedFp = "";
    private int sameFpSwipeCount = 0;
    private int pendingBundleOrderCount = 1;
    private String pendingOuterOrderFp = "";
    private boolean pendingOuterNeedsEscrow = false;
    private final Map<String, Boolean> rejectedFps = new HashMap<>();
    private Thread scannerThread;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        RunLogger.log("Dịch vụ Trợ năng DolongDAO đã kết nối thành công.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Giữ tĩnh tuyệt đối trong callback hệ thống
    }

    @Override
    public void onInterrupt() {
        stopScanner();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdownAll(null);
        instance = null;
        return super.onUnbind(intent);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()
        );
    }

    private int randInt(int min, int max) {
        if (max <= min) return min;
        return min + random.nextInt(max - min + 1);
    }

    private GradientDrawable roundBg(String hexColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(hexColor));
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }

    private void toastSafe(final String msg) {
        if (msg == null || msg.isEmpty()) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void vibrateSafe(long ms) {
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(ms);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void playAlertTone(final boolean isVictory) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    vibrateSafe(isVictory ? 1200 : 700);
                    ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
                    int tone = isVictory ? ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD : ToneGenerator.TONE_PROP_BEEP2;
                    tg.startTone(tone, 800);
                    Thread.sleep(850);
                    if (isVictory) {
                        tg.startTone(tone, 800);
                        Thread.sleep(850);
                    }
                    tg.release();
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    public Point performHumanClick(int baseX, int baseY, int radius, String actionTag) {
        int r = radius > 0 ? radius : 10;
        int x = Math.max(10, baseX + randInt(-r, r));
        int y = Math.max(10, baseY + randInt(-r, r));
        int pressDur = randInt(48, 86);
        try {
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, pressDur);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(stroke);
            dispatchGesture(b.build(), null, null);
            if (actionTag != null) {
                RunLogger.log("👆 Click [" + actionTag + "] tại (" + x + ", " + y + ") [Gốc: " + baseX + "," + baseY + " | Nhấn: " + pressDur + "ms]");
            }
        } catch (Exception e) {
            RunLogger.log("⚠️ Lỗi Click [" + actionTag + "]: " + e.getMessage());
        }
        return new Point(x, y);
    }

    public int performCurvedSwipe(AppConfig cfg) {
        int sx = Math.max(20, cfg.swipeStartX + randInt(-14, 14));
        int sy = Math.max(50, cfg.swipeStartY + randInt(-10, 10));
        int ex = Math.max(20, cfg.swipeEndX + randInt(-14, 14));
        int ey = Math.max(50, cfg.swipeEndY + randInt(-10, 10));

        // Điểm uốn giữa tạo đường cong Bezier tự nhiên như ngón tay cái quẹt
        int midX = (sx + ex) / 2 + randInt(-15, 15);
        int midY = (sy + ey) / 2 + randInt(-14, 14);

        // Biến thiên thời gian vuốt ±100ms (giữ tối thiểu >= 100ms để Android nhận vuốt mượt)
        int dur = Math.max(100, cfg.swipeDurationMs + randInt(-100, 100));

        try {
            Path p = new Path();
            p.moveTo(sx, sy);
            p.quadTo(midX, midY, ex, ey);
            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, dur);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(stroke);
            dispatchGesture(b.build(), null, null);
            RunLogger.log("👉 Vuốt đơn: TĐ2(" + sx + "," + sy + ") -> Cong(" + midX + "," + midY + ") -> TĐ1(" + ex + "," + ey + ") trong " + dur + "ms");
        } catch (Exception e) {
            RunLogger.log("⚠️ Lỗi Vuốt đơn: " + e.getMessage());
        }
        return dur;
    }

    private void tapReloadMap(AppConfig cfg) {
        performHumanClick(cfg.reloadX, cfg.reloadY, 10, "Load Map");
    }

    private void tapExpandDetail(AppConfig cfg) {
        performHumanClick(cfg.expandX, cfg.expandY, 10, "Mở Rộng Đơn Chùm");
    }

    private void tapBackFromDetail(AppConfig cfg) {
        performHumanClick(cfg.backX, cfg.backY, 10, "Quay Lại Từ Chi Tiết");
    }

    private void setHudRunButtonUi(final boolean running) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (btnToggleRun != null) {
                    if (running) {
                        btnToggleRun.setText("DỪNG");
                        btnToggleRun.setBackground(roundBg("#EA580C", 8));
                    } else {
                        btnToggleRun.setText("CHẠY");
                        btnToggleRun.setBackground(roundBg("#10B981", 8));
                    }
                }
            }
        });
    }

    public void showFloatingHud() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!Settings.canDrawOverlays(TouchAssistService.this)) {
                    toastSafe("Vui lòng cấp quyền Hiển thị trên ứng dụng khác!");
                    return;
                }
                removeCrosshairsOnUiThread();
                if (hudView != null) {
                    return;
                }

                LinearLayout root = new LinearLayout(TouchAssistService.this);
                root.setOrientation(LinearLayout.HORIZONTAL);
                root.setGravity(Gravity.CENTER_VERTICAL);
                root.setPadding(dp(8), dp(5), dp(8), dp(5));
                root.setBackground(roundBg("#EE1E293B", 14));

                TextView tvDrag = new TextView(TouchAssistService.this);
                tvDrag.setText("✥");
                tvDrag.setTextColor(Color.parseColor("#94A3B8"));
                tvDrag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                tvDrag.setPadding(dp(6), dp(2), dp(8), dp(2));
                root.addView(tvDrag);

                btnToggleRun = createHudButton("CHẠY", "#10B981", 64);
                LinearLayout.LayoutParams lpRun = (LinearLayout.LayoutParams) btnToggleRun.getLayoutParams();
                lpRun.rightMargin = dp(4);
                root.addView(btnToggleRun);

                Button btnPin = createHudButton("📌", "#F59E0B", 38);
                LinearLayout.LayoutParams lpPin = (LinearLayout.LayoutParams) btnPin.getLayoutParams();
                lpPin.rightMargin = dp(4);
                root.addView(btnPin);

                Button btnCfg = createHudButton("⚙️", "#0284C7", 38);
                LinearLayout.LayoutParams lpCfg = (LinearLayout.LayoutParams) btnCfg.getLayoutParams();
                lpCfg.rightMargin = dp(4);
                root.addView(btnCfg);

                Button btnClose = createHudButton("X", "#EF4444", 36);
                root.addView(btnClose);

                hudParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                hudParams.gravity = Gravity.TOP | Gravity.START;
                hudParams.x = 30;
                hudParams.y = 140;

                tvDrag.setOnTouchListener(new View.OnTouchListener() {
                    private float downX, downY;
                    private int origX, origY;

                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                downX = event.getRawX();
                                downY = event.getRawY();
                                origX = hudParams.x;
                                origY = hudParams.y;
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                hudParams.x = origX + (int) (event.getRawX() - downX);
                                hudParams.y = origY + (int) (event.getRawY() - downY);
                                try {
                                    wm.updateViewLayout(hudView, hudParams);
                                } catch (Exception ignored) {
                                }
                                return true;
                        }
                        return true;
                    }
                });

                btnToggleRun.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!isScanning) {
                            sessionStartTimeMs = System.currentTimeMillis();
                            setHudRunButtonUi(true);
                            toastSafe("▶️ Bắt đầu lọc đơn!");
                            startScanner();
                        } else {
                            stopScanner();
                            setHudRunButtonUi(false);
                            RunLogger.log("⏸ Người dùng bấm DỪNG quét.");
                            toastSafe("⏸ Đã dừng quét hoàn toàn (Tĩnh 100%).");
                        }
                    }
                });

                btnPin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        handlePinBadShopClick();
                    }
                });

                btnCfg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        stopScanner();
                        removePinModalOnUiThread();
                        removeEscrowModalOnUiThread();
                        removeHudViewOnUiThread();
                        Intent it = new Intent(TouchAssistService.this, MainPanelActivity.class);
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(it);
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        shutdownAll("Đã tắt Thanh Nổi.");
                    }
                });

                hudView = root;
                try {
                    wm.addView(hudView, hudParams);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private Button createHudButton(String text, String bgHex, int widthDp) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setAllCaps(false);
        b.setBackground(roundBg(bgHex, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(34));
        b.setLayoutParams(lp);
        return b;
    }

    // Các hàm xóa cửa sổ chạy trực tiếp trên UI Thread để tuyệt đối không xảy ra lỗi bất đồng bộ xóa nhầm bảng mới
    private void removeHudViewOnUiThread() {
        if (hudView != null) {
            try {
                wm.removeView(hudView);
            } catch (Exception ignored) {
            }
            hudView = null;
        }
    }

    private void removeEscrowModalOnUiThread() {
        if (escrowView != null) {
            try {
                wm.removeView(escrowView);
            } catch (Exception ignored) {
            }
            escrowView = null;
        }
    }

    private void removePinModalOnUiThread() {
        if (pinModalView != null) {
            try {
                wm.removeView(pinModalView);
            } catch (Exception ignored) {
            }
            pinModalView = null;
        }
    }

    private void removeCrosshairsOnUiThread() {
        for (View v : crosshairViews) {
            try {
                wm.removeView(v);
            } catch (Exception ignored) {
            }
        }
        crosshairViews.clear();
    }

    public void shutdownAll(final String msg) {
        stopScanner();
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                removeEscrowModalOnUiThread();
                removePinModalOnUiThread();
                removeCrosshairsOnUiThread();
                removeHudViewOnUiThread();
                if (msg != null && !msg.isEmpty()) {
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showEscrowTopupFloatingButton(final int minRequiredVnd, final String orderFp) {
        if (escrowView != null) return;
        isWaitingEscrowTopup = true;
        playAlertTone(false);
        final int reqK = (int) Math.ceil(minRequiredVnd / 1000.0);
        RunLogger.log("⚠️ Phát hiện đơn cần Ký quỹ tối thiểu: " + reqK + "K (Cho phép tối đa: " + AppConfig.load(this).maxEscrowMinK + "K) -> Hiện hộp chờ nạp quỹ.");

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                removeEscrowModalOnUiThread();
                LinearLayout card = new LinearLayout(TouchAssistService.this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                card.setBackground(roundBg("#FFFBEB", 14));

                LinearLayout topRow = new LinearLayout(TouchAssistService.this);
                topRow.setOrientation(LinearLayout.HORIZONTAL);
                topRow.setGravity(Gravity.CENTER_VERTICAL);

                TextView tvDrag = new TextView(TouchAssistService.this);
                tvDrag.setText("✥ ");
                tvDrag.setTextColor(Color.parseColor("#B45309"));
                tvDrag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                topRow.addView(tvDrag);

                TextView tvInfo = new TextView(TouchAssistService.this);
                tvInfo.setText("⚠️ Quỹ tối thiểu: " + reqK + "K (Kéo ✥)");
                tvInfo.setTextColor(Color.parseColor("#DC2626"));
                tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                tvInfo.setTypeface(Typeface.DEFAULT_BOLD);
                topRow.addView(tvInfo);
                card.addView(topRow);

                LinearLayout btnRow = new LinearLayout(TouchAssistService.this);
                btnRow.setOrientation(LinearLayout.HORIZONTAL);
                btnRow.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                );
                lpRow.topMargin = dp(8);
                btnRow.setLayoutParams(lpRow);

                Button btnSkip = createHudButton("BỎ QUA", "#64748B", 82);
                LinearLayout.LayoutParams lpSkip = (LinearLayout.LayoutParams) btnSkip.getLayoutParams();
                lpSkip.rightMargin = dp(8);

                Button btnDone = createHudButton("ĐÃ NẠP", "#16A34A", 88);
                btnRow.addView(btnSkip);
                btnRow.addView(btnDone);
                card.addView(btnRow);

                final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lp.gravity = Gravity.TOP | Gravity.START;
                lp.x = 60;
                lp.y = 280;

                tvDrag.setOnTouchListener(new View.OnTouchListener() {
                    private float dx, dy;
                    private int wx, wy;
                    @Override
                    public boolean onTouch(View v, MotionEvent ev) {
                        switch (ev.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                dx = ev.getRawX();
                                dy = ev.getRawY();
                                wx = lp.x;
                                wy = lp.y;
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                lp.x = wx + (int) (ev.getRawX() - dx);
                                lp.y = wy + (int) (ev.getRawY() - dy);
                                try {
                                    wm.updateViewLayout(escrowView, lp);
                                } catch (Exception ignored) {
                                }
                                return true;
                        }
                        return true;
                    }
                });

                btnSkip.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (orderFp != null && !orderFp.isEmpty()) {
                            rejectedFps.put(orderFp, true);
                        }
                        RunLogger.log("Người dùng bấm [BỎ QUA] đơn ký quỹ.");
                        removeEscrowModalOnUiThread();
                        isWaitingEscrowTopup = false;
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                ScreenParser.ParsedScreen cur = ScreenParser.parseShopeeScreen(
                                    ScreenParser.readCurrentScreenItems(TouchAssistService.this)
                                );
                                if (cur != null && "ESCROW_DIALOG".equals(cur.screenType) && cur.dialogCancelBtnPoint != null) {
                                    performHumanClick(cur.dialogCancelBtnPoint.x, cur.dialogCancelBtnPoint.y, 10, "Đóng Hộp Ký Quỹ");
                                }
                            }
                        }).start();
                    }
                });

                btnDone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (orderFp != null && !orderFp.isEmpty()) {
                            AppConfig cfg = AppConfig.load(TouchAssistService.this);
                            cfg.savedWhitelistedFp = orderFp;
                            cfg.savedWhitelistedTime = System.currentTimeMillis();
                            cfg.save(TouchAssistService.this);
                        }
                        RunLogger.log("Người dùng bấm [ĐÃ NẠP] -> Đã lưu Whitelist đơn ký quỹ: " + orderFp);
                        removeEscrowModalOnUiThread();
                        isWaitingEscrowTopup = false;
                        toastSafe("Đã nhớ đơn Ký Quỹ! Gặp lại sẽ tự động bấm Nhận.");
                    }
                });

                escrowView = card;
                try {
                    wm.addView(escrowView, lp);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void handlePinBadShopClick() {
        // Nếu đang quét thì tự động tạm dừng để thẻ đơn đứng yên cho người dùng chọn/xác nhận Ghim
        if (isScanning) {
            stopScanner();
            setHudRunButtonUi(false);
            RunLogger.log("📌 Tạm dừng quét để mở bảng Ghim Shop/Quán Khê.");
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<ScreenParser.NodeItem> items = ScreenParser.readCurrentScreenItems(TouchAssistService.this);
                final ScreenParser.ParsedScreen parsed = ScreenParser.parseShopeeScreen(items);
                if (parsed == null) {
                    RunLogger.log("📌 Bấm Ghim nhưng không đọc được cây giao diện màn hình.");
                    toastSafe("Không đọc được màn hình Shopee!");
                    return;
                }
                if ("DETAIL_SCREEN".equals(parsed.screenType) && !parsed.detailPickupList.isEmpty()) {
                    RunLogger.log("📌 Mở danh sách chọn Shop Khê trong màn Chi tiết (" + parsed.detailPickupList.size() + " điểm lấy).");
                    showPinDetailListOverlay(parsed.detailPickupList);
                    return;
                }
                if (parsed.pickupAddressText != null && !parsed.pickupAddressText.isEmpty()) {
                    RunLogger.log("📌 Mở bảng xác nhận Ghim Shop: " + parsed.pickupLabelText + " | " + parsed.pickupAddressText);
                    showPinConfirmOverlay(parsed.pickupLabelText, parsed.pickupAddressText);
                    return;
                }
                RunLogger.log("📌 Bấm Ghim nhưng màn hình hiện tại (" + parsed.screenType + ") không có địa chỉ lấy hàng.");
                toastSafe("Hãy mở màn hình có đơn Shopee rồi bấm [📌]!");
            }
        }).start();
    }

    private void showPinDetailListOverlay(final List<String> pickupList) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                removePinModalOnUiThread();

                LinearLayout box = new LinearLayout(TouchAssistService.this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(14), dp(12), dp(14), dp(12));
                box.setBackground(roundBg("#FFFFFF", 14));

                TextView tvTitle = new TextView(TouchAssistService.this);
                tvTitle.setText("📌 Chọn Điểm lấy (Shop khê) trong chùm đơn:");
                tvTitle.setTextColor(Color.parseColor("#0F172A"));
                tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
                box.addView(tvTitle);

                ScrollView sv = new ScrollView(TouchAssistService.this);
                LinearLayout listHost = new LinearLayout(TouchAssistService.this);
                listHost.setOrientation(LinearLayout.VERTICAL);
                listHost.setPadding(0, dp(8), 0, dp(8));

                for (int i = 0; i < pickupList.size(); i++) {
                    final String addr = pickupList.get(i);
                    Button itemBtn = new Button(TouchAssistService.this);
                    itemBtn.setText((i + 1) + ". " + addr);
                    itemBtn.setAllCaps(false);
                    itemBtn.setTextColor(Color.parseColor("#1E293B"));
                    itemBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                    itemBtn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                    itemBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
                    itemBtn.setBackground(roundBg("#F1F5F9", 8));
                    LinearLayout.LayoutParams lpItem = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                    );
                    lpItem.bottomMargin = dp(6);
                    itemBtn.setLayoutParams(lpItem);

                    itemBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            removePinModalOnUiThread();
                            showPinConfirmOverlay("", addr);
                        }
                    });
                    listHost.addView(itemBtn);
                }
                sv.addView(listHost);
                LinearLayout.LayoutParams lpSv = new LinearLayout.LayoutParams(
                    dp(315), LinearLayout.LayoutParams.WRAP_CONTENT
                );
                box.addView(sv, lpSv);

                Button btnCancel = createHudButton("ĐÓNG", "#64748B", 90);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        removePinModalOnUiThread();
                    }
                });
                box.addView(btnCancel);

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lp.gravity = Gravity.CENTER;
                pinModalView = box;
                try {
                    wm.addView(pinModalView, lp);
                } catch (Exception e) {
                    RunLogger.log("⚠️ Lỗi hiện danh sách Ghim: " + e.getMessage());
                }
            }
        });
    }

    private void showPinConfirmOverlay(final String sName, final String sAddr) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                removePinModalOnUiThread();

                LinearLayout box = new LinearLayout(TouchAssistService.this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(16), dp(14), dp(16), dp(14));
                box.setBackground(roundBg("#FFFFFF", 14));

                TextView tvTitle = new TextView(TouchAssistService.this);
                tvTitle.setText("📌 Xác nhận Ghim Shop/Quán Khê");
                tvTitle.setTextColor(Color.parseColor("#EE4D2D"));
                tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
                box.addView(tvTitle);

                TextView tvBody = new TextView(TouchAssistService.this);
                String detail = ((sName != null && !sName.isEmpty()) ? (sName + "\n") : "") + sAddr;
                tvBody.setText(detail);
                tvBody.setTextColor(Color.parseColor("#1E293B"));
                tvBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                tvBody.setPadding(0, dp(8), 0, dp(12));
                LinearLayout.LayoutParams lpBody = new LinearLayout.LayoutParams(dp(295), LinearLayout.LayoutParams.WRAP_CONTENT);
                box.addView(tvBody, lpBody);

                LinearLayout row = new LinearLayout(TouchAssistService.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.END);

                Button btnNo = createHudButton("HỦY", "#64748B", 82);
                LinearLayout.LayoutParams lpNo = (LinearLayout.LayoutParams) btnNo.getLayoutParams();
                lpNo.rightMargin = dp(8);

                Button btnYes = createHudButton("GHIM NGAY", "#EE4D2D", 108);

                btnNo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        removePinModalOnUiThread();
                    }
                });

                btnYes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AppConfig cfg = AppConfig.load(TouchAssistService.this);
                        if (cfg.addShopToBlacklist(TouchAssistService.this, sName, sAddr)) {
                            vibrateSafe(150);
                            RunLogger.log("✅ Đã thêm vào Blacklist Shop Khê: [" + sName + "] " + sAddr);
                            toastSafe("📌 Đã lưu vào danh sách Shop/Quán Khê!");
                        } else {
                            RunLogger.log("ℹ️ Shop đã có sẵn trong Blacklist: " + sAddr);
                            toastSafe("Shop/Quán này đã có trong Blacklist!");
                        }
                        removePinModalOnUiThread();
                    }
                });

                row.addView(btnNo);
                row.addView(btnYes);
                box.addView(row);

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lp.gravity = Gravity.CENTER;
                pinModalView = box;
                try {
                    wm.addView(pinModalView, lp);
                } catch (Exception e) {
                    RunLogger.log("⚠️ Lỗi hiện hộp xác nhận Ghim: " + e.getMessage());
                }
            }
        });
    }

    public void showCrosshairTargets() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!Settings.canDrawOverlays(TouchAssistService.this)) {
                    toastSafe("Hãy cấp quyền Vẽ trên ứng dụng khác trước!");
                    return;
                }
                removeCrosshairsOnUiThread();
                final AppConfig cfg = AppConfig.load(TouchAssistService.this);
                final int[] coords = new int[]{
                    cfg.reloadX, cfg.reloadY,
                    cfg.expandX, cfg.expandY,
                    cfg.backX, cfg.backY,
                    cfg.swipeStartX, cfg.swipeStartY,
                    cfg.swipeEndX, cfg.swipeEndY
                };

                addSingleCrosshair("🔄 Load Map", "#0284C7", coords[0], coords[1], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) { coords[0] = cx; coords[1] = cy; }
                });
                addSingleCrosshair("Mở rộng", "#EA580C", coords[2], coords[3], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) { coords[2] = cx; coords[3] = cy; }
                });
                addSingleCrosshair("Quay lại", "#7C3AED", coords[4], coords[5], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) { coords[4] = cx; coords[5] = cy; }
                });
                addSingleCrosshair("👉 TĐ2 (Đầu vuốt)", "#16A34A", coords[6], coords[7], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) { coords[6] = cx; coords[7] = cy; }
                });
                addSingleCrosshair("👈 TĐ1 (Cuối vuốt)", "#DC2626", coords[8], coords[9], new CoordCallback() {
                    @Override
                    public void onMove(int cx, int cy) { coords[8] = cx; coords[9] = cy; }
                });

                LinearLayout bar = new LinearLayout(TouchAssistService.this);
                bar.setOrientation(LinearLayout.HORIZONTAL);
                bar.setPadding(dp(10), dp(6), dp(10), dp(6));
                bar.setBackground(roundBg("#1E293B", 12));

                Button btnSave = createHudButton("LƯU 5 TỌA ĐỘ", "#10B981", 110);
                LinearLayout.LayoutParams lpS = (LinearLayout.LayoutParams) btnSave.getLayoutParams();
                lpS.rightMargin = dp(6);

                Button btnCancel = createHudButton("HỦY", "#EF4444", 54);
                bar.addView(btnSave);
                bar.addView(btnCancel);

                WindowManager.LayoutParams lpBar = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );
                lpBar.gravity = Gravity.TOP | Gravity.START;
                lpBar.x = 40;
                lpBar.y = 140;

                btnSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AppConfig c = AppConfig.load(TouchAssistService.this);
                        c.reloadX = coords[0]; c.reloadY = coords[1];
                        c.expandX = coords[2]; c.expandY = coords[3];
                        c.backX = coords[4]; c.backY = coords[5];
                        c.swipeStartX = coords[6]; c.swipeStartY = coords[7];
                        c.swipeEndX = coords[8]; c.swipeEndY = coords[9];
                        c.save(TouchAssistService.this);
                        RunLogger.log("🎯 Đã lưu 5 tọa độ mới từ Tâm ngắm kéo thả.");
                        removeCrosshairsOnUiThread();
                        toastSafe("Đã lưu cả 5 tọa độ mới!");
                    }
                });
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        removeCrosshairsOnUiThread();
                    }
                });

                crosshairViews.add(bar);
                try {
                    wm.addView(bar, lpBar);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private interface CoordCallback {
        void onMove(int cx, int cy);
    }

    private void addSingleCrosshair(String label, String hex, int initX, int initY, final CoordCallback cb) {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.parseColor("#44000000"));
        box.setPadding(dp(2), dp(2), dp(2), dp(2));

        TextView tvTag = new TextView(this);
        tvTag.setText(label);
        tvTag.setTextColor(Color.WHITE);
        tvTag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tvTag.setTypeface(Typeface.DEFAULT_BOLD);
        tvTag.setBackgroundColor(Color.parseColor(hex));
        tvTag.setPadding(dp(4), dp(1), dp(4), dp(1));
        box.addView(tvTag);

        TextView tvCross = new TextView(this);
        tvCross.setText("🎯");
        tvCross.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        box.addView(tvCross);

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = initX - 40;
        lp.y = initY - 40;

        tvCross.setOnTouchListener(new View.OnTouchListener() {
            private float dx, dy;
            private int wx, wy;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = event.getRawX();
                        dy = event.getRawY();
                        wx = lp.x;
                        wy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int nx = wx + (int) (event.getRawX() - dx);
                        int ny = wy + (int) (event.getRawY() - dy);
                        lp.x = nx;
                        lp.y = ny;
                        try {
                            wm.updateViewLayout(box, lp);
                        } catch (Exception ignored) {
                        }
                        cb.onMove(nx + 40, ny + 40);
                        return true;
                }
                return true;
            }
        });

        crosshairViews.add(box);
        try {
            wm.addView(box, lp);
        } catch (Exception ignored) {
        }
    }

    private boolean isWhitelistedOrderMatch(String fp, AppConfig cfg) {
        if (fp == null || fp.isEmpty() || cfg.savedWhitelistedFp == null || !fp.equals(cfg.savedWhitelistedFp)) {
            return false;
        }
        if (System.currentTimeMillis() - cfg.savedWhitelistedTime > 20L * 60L * 1000L) {
            cfg.savedWhitelistedFp = "";
            cfg.save(this);
            return false;
        }
        return true;
    }

    // Chờ đủ thời gian vuốt + thời gian trượt thẻ (220ms) trước khi đọc thẻ tiếp theo
    private ScreenParser.ParsedScreen waitForCardChangeAfterSwipe(String oldFp, int actualSwipeDurMs) {
        try {
            Thread.sleep(actualSwipeDurMs + 220);
        } catch (InterruptedException e) {
            return null;
        }
        long startPoll = System.currentTimeMillis();
        while (System.currentTimeMillis() - startPoll < 550) {
            ScreenParser.ParsedScreen sc = ScreenParser.parseShopeeScreen(readNodesNow());
            if (sc == null) {
                try { Thread.sleep(65); } catch (InterruptedException e) { return null; }
                continue;
            }
            if ("END_OF_CARDS".equals(sc.screenType) || "EMPTY_MAP".equals(sc.screenType)) {
                return sc;
            }
            if ("OUTER_CARD".equals(sc.screenType) && sc.fingerprint != null && !sc.fingerprint.isEmpty()
                    && !sc.fingerprint.equals(oldFp) && sc.dropoffAddressText != null && !sc.dropoffAddressText.isEmpty()) {
                return sc;
            }
            try { Thread.sleep(65); } catch (InterruptedException e) { return null; }
        }
        return ScreenParser.parseShopeeScreen(readNodesNow());
    }

    // Sau khi bấm Load Map, chờ đúng thời gian cài đặt (loadMapDelayMs ± 100ms), nhưng nếu thẻ đơn xuất hiện sớm sau 700ms thì bắt luôn
    private ScreenParser.ParsedScreen waitAfterLoadMapClick(AppConfig cfg) throws InterruptedException {
        int targetWaitMs = Math.max(400, cfg.loadMapDelayMs + randInt(-100, 100));
        RunLogger.log("⏳ Đang chờ Load Map trong " + targetWaitMs + "ms (Cài đặt: " + cfg.loadMapDelayMs + "ms ±100ms)...");

        int initialSleep = Math.min(700, targetWaitMs);
        Thread.sleep(initialSleep);
        long startWait = System.currentTimeMillis() - initialSleep;

        while (isScanning && (System.currentTimeMillis() - startWait < targetWaitMs)) {
            ScreenParser.ParsedScreen sc = ScreenParser.parseShopeeScreen(readNodesNow());
            if (sc != null && "OUTER_CARD".equals(sc.screenType)) {
                RunLogger.log("⚡ Đơn đã hiện lên sau " + (System.currentTimeMillis() - startWait) + "ms -> Vào lọc ngay!");
                return sc;
            }
            Thread.sleep(120);
        }
        return ScreenParser.parseShopeeScreen(readNodesNow());
    }

    private List<ScreenParser.NodeItem> readNodesNow() {
        return ScreenParser.readCurrentScreenItems(this);
    }

    private void stopScanner() {
        isScanning = false;
        if (scannerThread != null) {
            try {
                scannerThread.interrupt();
            } catch (Exception ignored) {
            }
            scannerThread = null;
        }
    }

    private void startScanner() {
        stopScanner();
        final AppConfig cfg = AppConfig.load(this);
        isScanning = true;
        if (sessionStartTimeMs == 0L) {
            sessionStartTimeMs = System.currentTimeMillis();
        }
        rejectedFps.clear();
        lastSwipedFp = "";
        sameFpSwipeCount = 0;

        RunLogger.log("▶️ BẮT ĐẦU CHẠY | Chế độ: " + cfg.runMode
            + " | Ưu tiên: " + cfg.priorityMinutes + "p | Quỹ: " + cfg.maxEscrowMinK
            + "K | LoadMap: " + cfg.loadMapDelayMs + "ms | Vuốt: " + cfg.swipeDurationMs + "ms");

        scannerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                ScreenParser.ParsedScreen cachedScreen = null;

                // Kiểm tra ngay màn hình hiện tại: nếu chưa có thẻ đơn trên màn hình mới bấm Load Map đầu tiên
                try {
                    ScreenParser.ParsedScreen firstCheck = ScreenParser.parseShopeeScreen(readNodesNow());
                    if (firstCheck != null && ("OUTER_CARD".equals(firstCheck.screenType) || "DETAIL_SCREEN".equals(firstCheck.screenType))) {
                        RunLogger.log("🔍 Đã có sẵn đơn trên màn hình lúc bấm CHẠY -> Kiểm tra ngay không cần bấm Load Map.");
                        cachedScreen = firstCheck;
                    } else {
                        tapReloadMap(cfg);
                        cachedScreen = waitAfterLoadMapClick(cfg);
                    }
                } catch (InterruptedException e) {
                    return;
                }

                while (isScanning && !Thread.currentThread().isInterrupted()) {
                    try {
                        if (isWaitingEscrowTopup) {
                            Thread.sleep(400);
                            continue;
                        }

                        long elapsedMs = System.currentTimeMillis() - sessionStartTimeMs;
                        boolean useNormalToo = (elapsedMs >= (long) cfg.priorityMinutes * 60L * 1000L);

                        ScreenParser.ParsedScreen screen = (cachedScreen != null)
                            ? cachedScreen
                            : ScreenParser.parseShopeeScreen(readNodesNow());
                        cachedScreen = null;

                        if (screen == null || "UNKNOWN".equals(screen.screenType)) {
                            Thread.sleep(randInt(260, 360));
                            continue;
                        }

                        if ("EMPTY_MAP".equals(screen.screenType)) {
                            RunLogger.log("🗺️ Màn hình trống (Không có đơn free-pick) -> Bấm Load Map.");
                            tapReloadMap(cfg);
                            cachedScreen = waitAfterLoadMapClick(cfg);
                            continue;
                        }

                        if ("END_OF_CARDS".equals(screen.screenType)) {
                            RunLogger.log("🔚 Đã vuốt hết danh sách thẻ đơn -> Bấm Tải lại trang / Load Map.");
                            lastMapDotsSig = screen.mapDotsSignature;
                            rejectedFps.clear();
                            lastSwipedFp = "";
                            sameFpSwipeCount = 0;

                            if (screen.reloadPageBtnPoint != null) {
                                performHumanClick(screen.reloadPageBtnPoint.x, screen.reloadPageBtnPoint.y, 12, "Nút Tải Lại Trang");
                            } else {
                                tapReloadMap(cfg);
                            }
                            cachedScreen = waitAfterLoadMapClick(cfg);
                            continue;
                        }

                        if ("ESCROW_DIALOG".equals(screen.screenType)) {
                            int reqVnd = screen.escrowMinRequiredVnd != null ? screen.escrowMinRequiredVnd : 0;
                            int maxAllowedVnd = cfg.maxEscrowMinK * 1000;
                            if (reqVnd > 0 && reqVnd <= maxAllowedVnd) {
                                showEscrowTopupFloatingButton(reqVnd, pendingOuterOrderFp);
                            } else {
                                RunLogger.log("❌ Quỹ yêu cầu (" + (reqVnd / 1000) + "K) vượt mức tối đa (" + cfg.maxEscrowMinK + "K) -> Bấm Hủy.");
                                if (pendingOuterOrderFp != null && !pendingOuterOrderFp.isEmpty()) {
                                    rejectedFps.put(pendingOuterOrderFp, true);
                                }
                                if (screen.dialogCancelBtnPoint != null) {
                                    performHumanClick(screen.dialogCancelBtnPoint.x, screen.dialogCancelBtnPoint.y, 10, "Hủy Hộp Ký Quỹ");
                                } else {
                                    performHumanClick(315, 1369, 10, "Hủy Hộp Ký Quỹ");
                                }
                                Thread.sleep(randInt(340, 440));
                            }
                            continue;
                        }

                        if ("DETAIL_SCREEN".equals(screen.screenType)) {
                            int nPickups = Math.min(Math.max(pendingBundleOrderCount, 2), screen.detailPickupList.size());
                            boolean hitBadShop = false;
                            String badAddrFound = "";
                            for (int pIdx = 0; pIdx < nPickups; pIdx++) {
                                String pAddr = screen.detailPickupList.get(pIdx);
                                if (ScreenParser.isBadShopMatch("", pAddr, cfg)) {
                                    hitBadShop = true;
                                    badAddrFound = pAddr;
                                    break;
                                }
                            }
                            boolean detailGeoOk = true;
                            if ("SHOPEE".equals(cfg.runMode) && screen.dropoffAddressText != null && !screen.dropoffAddressText.isEmpty()) {
                                detailGeoOk = ScreenParser.checkFinalDropoffArea(screen.dropoffAddressText, cfg, useNormalToo);
                            }
                            if (hitBadShop || !detailGeoOk) {
                                if (hitBadShop) {
                                    RunLogger.log("❌ Chi tiết chùm đơn dính Shop Khê: [" + badAddrFound + "] -> Bấm Quay lại.");
                                } else {
                                    RunLogger.log("❌ Chi tiết chùm đơn sai Quận giao cuối: [" + screen.dropoffAddressText + "] -> Bấm Quay lại.");
                                }
                                if (pendingOuterOrderFp != null && !pendingOuterOrderFp.isEmpty()) {
                                    rejectedFps.put(pendingOuterOrderFp, true);
                                }
                                tapBackFromDetail(cfg);
                                Thread.sleep(randInt(380, 480));
                                continue;
                            }
                            if (screen.acceptBtnPoint != null) {
                                RunLogger.log("🎯 Chùm đơn SẠCH 100% -> Bấm NHẬN ĐƠN trong Chi tiết!");
                                performHumanClick(screen.acceptBtnPoint.x, screen.acceptBtnPoint.y, 12, "Nhận Chùm Đơn");
                                Thread.sleep(360);
                                if (!pendingOuterNeedsEscrow) {
                                    playAlertTone(true);
                                    shutdownAll("🎯 ĐÃ NHẬN CHÙM ĐƠN THÀNH CÔNG!");
                                    break;
                                }
                            }
                            continue;
                        }

                        if ("OUTER_CARD".equals(screen.screenType)) {
                            String fp = screen.fingerprint;
                            if (isWhitelistedOrderMatch(fp, cfg) && screen.acceptBtnPoint != null) {
                                RunLogger.log("🎯 Gặp lại đơn Whitelist đã nạp Ký quỹ -> Bấm NHẬN ĐƠN ngay!");
                                performHumanClick(screen.acceptBtnPoint.x, screen.acceptBtnPoint.y, 12, "Nhận Đơn Ký Quỹ");
                                cfg.savedWhitelistedFp = "";
                                cfg.save(TouchAssistService.this);
                                Thread.sleep(360);
                                playAlertTone(true);
                                shutdownAll("🎯 ĐÃ NHẬN ĐƠN KÝ QUỸ THÀNH CÔNG!");
                                break;
                            }

                            // Nếu đơn này đã bị đánh dấu loại (ví dụ vừa từ Chi tiết quay ra hoặc vừa vuốt chưa qua hết)
                            if (fp != null && Boolean.TRUE.equals(rejectedFps.get(fp))) {
                                if (fp.equals(lastSwipedFp)) {
                                    sameFpSwipeCount++;
                                    if (sameFpSwipeCount >= 2) {
                                        RunLogger.log("🔄 Đã vuốt 2 lần mà vẫn ở thẻ cuối (" + screen.moneyRawText + " | " + screen.kmRawText + ") -> Hết thẻ, bấm Load Map.");
                                        rejectedFps.clear();
                                        lastSwipedFp = "";
                                        sameFpSwipeCount = 0;
                                        tapReloadMap(cfg);
                                        cachedScreen = waitAfterLoadMapClick(cfg);
                                        continue;
                                    }
                                } else {
                                    lastSwipedFp = fp;
                                    sameFpSwipeCount = 1;
                                }
                                int durSwipe = performCurvedSwipe(cfg);
                                cachedScreen = waitForCardChangeAfterSwipe(fp, durSwipe);
                                continue;
                            }

                            RunLogger.log("📦 Đọc thẻ: [" + screen.orderType + " | " + screen.orderCount + " đơn | "
                                + screen.kmRawText + " | " + screen.moneyRawText + "] Lấy: " + screen.pickupAddressText
                                + " -> Giao: " + screen.dropoffAddressText);

                            ScreenParser.EvalResult eval = ScreenParser.evaluateOuterOrderCardWithReason(screen, cfg, useNormalToo);
                            if (!eval.pass) {
                                RunLogger.log("   ↳ ❌ LOẠI: " + eval.reason);
                                if (fp != null && !fp.isEmpty()) {
                                    rejectedFps.put(fp, true);
                                }
                                lastSwipedFp = fp;
                                sameFpSwipeCount = 1;
                                int durSwipe = performCurvedSwipe(cfg);
                                cachedScreen = waitForCardChangeAfterSwipe(fp, durSwipe);
                                continue;
                            }

                            RunLogger.log("   ↳ ✅ ĐẠT: " + eval.reason);
                            pendingOuterOrderFp = fp;
                            pendingOuterNeedsEscrow = screen.needsEscrow;
                            pendingBundleOrderCount = screen.orderCount;

                            if (screen.orderCount >= 2) {
                                RunLogger.log("   ↳ 🔍 Đơn chùm (" + screen.orderCount + " đơn) -> Bấm Mở rộng kiểm tra chi tiết từng điểm lấy.");
                                tapExpandDetail(cfg);
                                Thread.sleep(randInt(380, 460));
                                continue;
                            }
                            if (screen.needsEscrow) {
                                RunLogger.log("   ↳ 💰 Đơn thiếu ký quỹ -> Bấm mở thanh ký quỹ để đọc số tiền tối thiểu.");
                                if (screen.escrowBarPoint != null) {
                                    performHumanClick(screen.escrowBarPoint.x, screen.escrowBarPoint.y, 12, "Thanh Ký Quỹ");
                                } else {
                                    performHumanClick(540, 2275, 12, "Thanh Ký Quỹ");
                                }
                                Thread.sleep(randInt(380, 460));
                                continue;
                            } else if (screen.acceptBtnPoint != null) {
                                RunLogger.log("   ↳ 🎯 Bấm NHẬN ĐƠN ngay!");
                                performHumanClick(screen.acceptBtnPoint.x, screen.acceptBtnPoint.y, 12, "Nhận Đơn");
                                Thread.sleep(360);
                                playAlertTone(true);
                                shutdownAll("🎯 ĐÃ NHẬN ĐƠN THÀNH CÔNG!");
                                break;
                            }
                        }

                        Thread.sleep(randInt(240, 340));
                    } catch (InterruptedException ie) {
                        break;
                    } catch (Exception e) {
                        RunLogger.log("⚠️ Lỗi vòng lặp: " + e.getMessage());
                        try { Thread.sleep(300); } catch (InterruptedException ie) { break; }
                    }
                }
            }
        });
        scannerThread.start();
    }
}
